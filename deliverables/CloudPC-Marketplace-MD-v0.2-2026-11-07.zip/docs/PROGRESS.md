# Tiến độ Cloud PC Marketplace

Thời gian trong tài liệu theo Asia/Saigon. Nguồn quyết định: [APPROVAL](APPROVAL.md).

## Trạng thái hiện tại

**DRAFT — CHỜ CHỦ DỰ ÁN DUYỆT. Chỉ có tài liệu, chưa triển khai ứng dụng.**

| Mốc | Trạng thái | Bằng chứng |
| --- | --- | --- |
| P0 — bộ tài liệu chuẩn bị | Có bản đầu, nghiên cứu streaming và thiết kế 0.2 chờ duyệt | 21 file hiện hành và 7 file lưu trữ |
| Duyệt ý tưởng/MVP/quyền | Chưa duyệt | APPROVAL còn chờ |
| M0 — remote spike | Chưa bắt đầu | Chưa có máy được chỉ định |
| M1 — web và dữ liệu | Chưa bắt đầu | Chưa có mã ứng dụng |
| M2 — contract local | Chưa bắt đầu | Chưa có Solidity/tests |
| M3 — gateway và worker | Chưa bắt đầu | Chưa có adapter được kiểm chứng |
| M4 — Fuji/deploy | Chưa bắt đầu | Chưa có address/tx/URL |
| M5 — review và bài nộp | Chưa bắt đầu | Chưa có video/slide/Submit |

## 07/11/2026 — yêu cầu và tài liệu

Chủ dự án chọn hướng Cloud PC, sau đó muốn người có máy cho người cần máy thuê. Yêu cầu mới nhất: viết tất cả Markdown để Claude/Codex chuẩn bị và đưa chủ dự án duyệt.

Đã làm:

- Đọc bộ README/AGENTS/CLAUDE/MVP/PROGRESS/DEVELOPMENT_GUIDE cũ.
- Sao lưu sáu file UniAct vào docs/archive/uniact-2026-11-03, đối chiếu SHA-256 với bản gốc trước thay đổi.
- Đối chiếu FAQ BTC và tài liệu chính thức về network, công cụ web/contract, auth và remote.
- Soạn ý tưởng, phiếu duyệt, MVP, kiến trúc, dữ liệu/API, escrow, remote, bảo mật, test plan, lộ trình, workflow agent và bài nộp.
- Phân biệt yêu cầu thật của chủ dự án với đề xuất chưa duyệt; không coi tư vấn trước đó là quyết định chọn stack/gói/giá.

Kiểm tra tài liệu đã thực hiện:

- Liệt kê 24 file Markdown: 17 file hiện hành, 6 bản UniAct và 1 trang giải thích lưu trữ.
- Duyệt các liên kết Markdown tương đối trên toàn bộ 24 file: không có đích file bị thiếu ở lần kiểm tra.
- Rà soát tham số: gói 15 phút, 0.01 AVAX Fuji, phí 10% phần gross host, quote tối đa 10 phút, activateBy=fundBy+5 phút, grace 10 phút, phân xử 24 giờ.
- Làm rõ startedAt từ block kích hoạt và việc chờ xác nhận nằm trong gói; không dùng client clock làm chuẩn.
- Định nghĩa archive là lịch sử, mọi đề xuất D01–D12 vẫn chờ duyệt.

Bàn giao: deliverables/CloudPC-Marketplace-MD-Draft-2026-11-07.zip. Đã tạo ZIP, kiểm tra đủ 24 Markdown, đường dẫn tương đối hợp lệ và SHA-256 từng entry khớp file nguồn. Khi cập nhật nhật ký này, đóng gói lại và đối chiếu nội dung lần cuối để ZIP chứa đúng phiên bản bàn giao.

Không có kiểm thử ứng dụng nào được chạy vì chưa có mã ứng dụng. Việc kiểm tra liên kết/ZIP không chứng minh kiến trúc, remote hoặc contract đã chạy.

Chưa làm:

- Không scaffold/cài dependency ứng dụng, chưa tạo package manifest hoặc migration.
- Không viết contract/worker/host connector, không test build/dev của ứng dụng.
- Không cài công cụ remote, thay máy/OS, mở cổng, tạo tài khoản ngoài hoặc phát sinh chi phí.
- Không tạo/push repo GitHub, deploy web/hợp đồng hoặc gửi bài thi.
- Không có kết quả benchmark, người dùng, doanh thu hay đối tác.

## 07/11/2026 — nghiên cứu vận hành và độ mượt

Yêu cầu tiếp theo của chủ dự án: tìm hiểu cách vận hành marketplace và công nghệ kết nối hai máy mượt nhất có thể.

- Đọc nguồn chính thức AirGPU, TensorDock, Vast, Sunshine/Moonlight, Parsec, Selkies, Amazon DCV, Wolf và WebRTC.
- Thêm docs/STREAMING_RESEARCH.md: phân biệt marketplace/streamer, control/streaming plane, native/browser, NAT/relay, GPU và isolation.
- Đề xuất Sunshine/Moonlight làm baseline thử nghiệm, Selkies WebRTC cho browser Linux; chưa kết luận phần mềm nào nhanh nhất.
- Nêu D03/D11 cần xem lại theo ưu tiên mới; chưa tự duyệt hoặc thay MVP/contract.
- Chưa cài phần mềm, chạy benchmark, có thiết bị hoặc deploy. Không có kết quả latency/FPS thực tế.
- ZIP Draft-2026-11-07 đã gửi trước đó là bộ 24 Markdown ban đầu. Nghiên cứu mới được cung cấp riêng; không ghi đè bản ZIP cũ.

## 07/11/2026 — thiết kế cam kết host, chính sách và workspace

Chủ dự án đề nghị cụ thể hóa uptime/thời gian nhận thuê, cân nhắc cọc, chính sách, AI tư vấn, app kết nối, cloud portable và bảo mật hai phía.

- Thêm PLATFORM_DESIGN_V02, MARKETPLACE_POLICIES_DRAFT và CLOUD_WORKSPACES.
- Đề xuất cửa sổ host 4 giờ, pilot 30 phút–2 giờ, cloud theo project và host bond theo exposure; tất cả thông số/công thức chưa duyệt.
- Tách tiền thuê, cọc host, phí cloud; không đề xuất thu cọc renter hoặc slash tự động chỉ từ heartbeat.
- Phân biệt ephemeral/project/full-image; chỉ hứa checkpoint đã xác nhận và restore trên môi trường tương thích.
- Ghi rõ runtime privacy không được bảo đảm trước host quản trị; mã hóa/presigned URL không tự loại bỏ rủi ro.
- Cho phép nghiên cứu AI tư vấn theo yêu cầu mới, chưa đưa vào MVP hoặc gọi API trả phí.
- Cập nhật root docs/phiếu duyệt và đánh dấu các đặc tả 0.1 phải đồng bộ trước code phần mới; không triển khai theo prompt cũ.
- Chưa có tài nguyên, benchmark, storage sync, phần mềm hay contract được triển khai. Chưa có thông số kinh doanh/bảo mật được chứng minh.

Kiểm tra bàn giao 0.2: đã kiểm tra đủ 28 Markdown (21 hiện hành, 7 lưu trữ), không có liên kết file tương đối bị thiếu, code fence cân bằng. Đã đóng gói ZIP v0.2 riêng và đối chiếu SHA-256 từng entry; cập nhật nhật ký này được đóng gói lại trước khi bàn giao. ZIP cũ được giữ nguyên. Đây chỉ là kiểm tra tài liệu/đóng gói, không phải kiểm thử bảo mật hoặc tính khả thi trên máy.

## Điểm cần tiếp tục

1. Chủ dự án xem APPROVAL và PRODUCT/MVP rồi duyệt/sửa.
2. Nếu duyệt M0, xác định máy, quyền cấu hình, hai mạng và ngân sách cần thiết.
3. Writer làm mốc được giao; reviewer chỉ đọc. Không cho hai agent sửa checkout đồng thời.
4. Sau mỗi mốc ghi script/thao tác thực tế, kết quả, mocks và blocker.

## Mẫu ghi mốc sau

~~~text
Ngày và mốc:
Phạm vi đã được duyệt:
Writer / reviewer:
Commit (nếu có):
File/thay đổi chính:
Script và thao tác đã chạy:
Kết quả / bằng chứng:
Chưa kiểm tra / mock:
Sự cố / blocker:
Tiến trình hoặc job còn chạy:
Bước tiếp:
~~~

## Lịch sử trước khi chuyển ý tưởng

Ngày 03/11/2026, dự án là UniAct CTXH và mới có tài liệu. Xem kho archive để giữ nguyên lịch sử; không tiếp tục task UACT/CTXH trong hồ sơ đó.
