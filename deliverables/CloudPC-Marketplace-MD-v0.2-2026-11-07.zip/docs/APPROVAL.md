# Phiếu duyệt bản đề xuất

Phiên bản phiếu 0.2 — 07/11/2026, Asia/Saigon.

**Trạng thái: CHỜ DUYỆT. Chưa có quyết định duyệt triển khai.**

## 1. Đã được người dùng yêu cầu

- Chuyển hướng sang dịch vụ Cloud PC.
- Nghiên cứu mô hình người có máy cho người cần máy thuê, thay vì nền tảng sở hữu toàn bộ máy.
- Tầm nhìn phục vụ học tập/lập trình, game, đồ họa/AI.
- Chuẩn bị cho UniHack; viết bộ Markdown chung cho Claude/Codex và đưa người dùng duyệt trước.
- Yêu cầu mới: host cam kết máy/điện/mạng theo thời gian đăng cho thuê; xem xét cọc và chính sách; tìm máy/có thể AI tư vấn; chọn app kết nối; tùy chọn cloud dùng lại giữa host; bảo vệ dữ liệu hai phía. Thiết kế tại PLATFORM_DESIGN_V02, MARKETPLACE_POLICIES_DRAFT và CLOUD_WORKSPACES.

Yêu cầu viết tài liệu không tự động cho phép code, deploy, thuê cloud hoặc thay cấu hình máy.

## 2. Gói đề xuất cần duyệt

| ID | Nội dung đề xuất | Trạng thái |
| --- | --- | --- |
| D01 | Tên làm việc Cloud PC Marketplace, thương hiệu chốt sau | Chờ duyệt |
| D02 | Marketplace có duyệt chủ máy; 1 máy demo, 1 khách đồng thời | Chờ duyệt |
| D03 | OS/template và ứng dụng đầu cần chốt theo máy/GPU; Linux học lập trình là phương án cũ | Chờ duyệt lại |
| D04 | Host đăng cửa sổ nhận thuê; MVP thuê ngay, chưa đặt lịch trước | Chờ duyệt lại |
| D05 | Demo đề xuất 15 phút/0.01 AVAX Fuji/10%; pilot 30 phút–2 giờ là cấu hình khác chưa chốt | Chờ duyệt lại |
| D06 | AVAX Fuji native để giữ tiền; không phát hành đồng riêng | Chờ duyệt |
| D07 | Người thuê có thể hủy trước kích hoạt; khách xác nhận trả tiền hoặc hết hạn khiếu nại thì tất toán | Chờ duyệt |
| D08 | Khiếu nại do admin demo phân xử, quá hạn phân xử hoàn toàn bộ cho khách | Chờ duyệt |
| D09 | Có no-cloud và project workspace; cloud dùng tiếp giữa host, không hứa full OS/RAM migration | Chờ duyệt lại |
| D10 | Next.js/TypeScript, Supabase/PostgreSQL, Solidity/Hardhat, worker và gateway riêng | Chờ duyệt |
| D11 | Đề xuất spike Sunshine/Moonlight trước; browser là hướng riêng theo OS; chưa chọn engine cuối | Chờ duyệt lại |
| D12 | Thiết bị thật do chủ dự án chỉ định; không tự mua/thuê máy hay sửa hệ điều hành | Chờ duyệt |
| D13 | Cửa sổ host pilot đề xuất tối thiểu 4 giờ; buffer cần đo | Chờ duyệt |
| D14 | Cân nhắc host bond; chưa cọc renter, chưa chọn số tiền/công thức slash | Chờ duyệt |
| D15 | Chính sách phiên bản theo booking; sự cố đối soát, không phạt chỉ từ heartbeat | Chờ duyệt |
| D16 | AI tư vấn cấu hình chỉ đọc catalog, tùy chọn sau core flow | Chờ duyệt |
| D17 | Chứng minh project portability bằng hai host tuần tự; quota/retention/giá cloud cần chốt | Chờ duyệt |
| D18 | Host được duyệt, guest sạch; công bố không bảo đảm bí mật runtime trước host quản trị | Chờ duyệt |
| D19 | Nếu cần che IP peer, khảo sát relay và chi phí/độ trễ; chưa mặc định P2P vừa nhanh vừa ẩn IP | Chờ duyệt |
| D20 | Chốt checkpoint/recovery và cấp/thu hồi quyền cloud trước code persistence | Chờ duyệt |

0.01 AVAX và 10% là tham số minh họa testnet, không phải định giá thương mại. Một giờ thuê tương lai không mặc nhiên có giá bằng bốn lần gói demo.

## 3. Mốc và phạm vi duyệt

Chủ dự án có thể:

- Duyệt tài liệu để giữ làm bản kế hoạch, chưa code.
- Duyệt M0: kiểm tra công cụ, chuẩn bị và thử kết nối trên máy được chỉ định.
- Duyệt triển khai MVP theo mốc M0–M5, trong giới hạn tài nguyên được cho phép.
- Yêu cầu sửa các ID trước khi duyệt.

Khi duyệt MVP, agent được thực hiện tác vụ local cần thiết trong phạm vi đã duyệt, kiểm tra và sửa lỗi; không hỏi lại từng lệnh thường lệ. Hiện yêu cầu 0.2 mới hơn đặc tả code 0.1: trước phần phụ thuộc phải đồng bộ MVP, kiến trúc, dữ liệu, contract, kiểm thử và lịch theo quyết định. Nếu M0 thất bại, dừng phần phụ thuộc và trình bày phương án cụ thể; không tự thay bằng mock rồi báo đủ MVP.

## 4. Điều kiện ngoài tài liệu còn thiếu

| Cần biết | Hiện trạng | Ảnh hưởng |
| --- | --- | --- |
| Máy cho thuê và quyền cấu hình | Chưa có máy được chỉ định | Chặn thử remote thật |
| RAM, hệ điều hành, virtualization, quyền cài phần mềm | Chưa kiểm tra | Quyết định guest VM/gateway |
| Hai mạng để thử | Chưa xác nhận | Chưa chứng minh kết nối Internet |
| Ngân sách hạ tầng và tài khoản hiện có | Chưa được cấp | Chưa tạo gateway công khai hoặc dùng gói trả phí |
| Quyền deploy Fuji và URL web | Chưa được duyệt | Chỉ chuẩn bị script sau khi được code |
| Đăng ký đội/điều kiện đội thi | Chưa xác nhận trong phiên này | Chủ dự án cần tự kiểm tra trên BTC |

Các mục này không ngăn việc duyệt ý tưởng. Agent tiếp tục phần độc lập, chỉ hỏi khi cần thông tin cho mốc phụ thuộc.

## 5. Cách trả lời duyệt

Có thể dùng câu tự nhiên:

> Tôi duyệt ý tưởng và tài liệu, chưa code.

> Tôi duyệt các mục ... của bản 0.2 và cho chuẩn bị M0. Máy dùng thử là ...; phạm vi cài đặt cho phép là ...; ngân sách là ....

> Sửa D03 thành ... rồi gửi lại tôi xem.

Các câu trên chỉ là mẫu, không phải quyết định đã được đưa ra.

## 6. Nhật ký quyết định

| Thời điểm Việt Nam | Người quyết định | Nội dung | Phạm vi được phép |
| --- | --- | --- | --- |
| 07/11/2026 | Chủ dự án, yêu cầu trong chat | Soạn tất cả Markdown và gửi duyệt | Tài liệu, kiểm tra tài liệu, đóng gói |
| 07/11/2026 | Chủ dự án, yêu cầu trong chat | Phát triển thiết kế về uptime, cọc/chính sách, AI tư vấn, cloud và bảo mật | Nghiên cứu/thiết kế bổ sung; chưa có quyết định số tiền, thông số hay code |

Agent không tự điền ngày duyệt giả, không xem dấu checkbox hay gói ZIP là bằng chứng chủ dự án đã duyệt.
