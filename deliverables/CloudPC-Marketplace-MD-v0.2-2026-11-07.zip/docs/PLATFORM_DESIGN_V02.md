# Thiết kế sản phẩm 0.2 — chợ Cloud PC có cam kết và workspace

Ngày: 07/11/2026, Asia/Saigon. **DRAFT ĐỂ CHỦ DỰ ÁN DUYỆT. Chưa được phép triển khai từ tài liệu này.**

## 1. Hướng mới được người dùng yêu cầu

- Chủ máy tự đăng máy, cam kết nguồn điện/mạng và không tắt trong thời gian nhận cho thuê.
- Xác định thời gian cam kết tối thiểu và cân nhắc cọc/xử lý vi phạm.
- Có chính sách dành cho hai phía của chợ.
- Khách tìm theo cấu hình; có thể được AI tư vấn theo nhu cầu.
- Thuê xong dùng ứng dụng kết nối tối ưu hiệu năng.
- Có lựa chọn lưu cloud hoặc không; dữ liệu đã lưu dùng tiếp khi thuê máy chủ khác.
- Thiết kế bảo vệ dữ liệu cá nhân của cả người thuê và chủ máy.

Đây là yêu cầu/hướng nghiên cứu mới, không phải chấp thuận các thông số, AI API, khoản cọc hoặc triển khai trong bản đề xuất trước.

## 2. Mô hình đề xuất

Nền tảng có hai dịch vụ: marketplace thuê tài nguyên máy và workspace lưu dự án. Máy vật lý thuộc host; tài khoản/workspace thuộc khách trên nền tảng. Hợp đồng tiền và quyền storage không thuộc chủ máy.

Nền tảng vẫn phải vận hành auth, quản lý phiên, gateway/relay khi cần, storage/control plane và hỗ trợ. Không sở hữu PC không có nghĩa không có chi phí cloud.

## 3. Các lớp và vòng đời

1. Host được duyệt, cài agent và chuẩn bị guest/máy chuyên để thuê.
2. Kiểm tra cấu hình, encoder, mạng, reset và phương án điện; ghi kết quả với thời điểm.
3. Host đăng khoảng nhận thuê, giá và thời lượng tối đa.
4. Khách chọn cấu hình hoặc hỏi AI tư vấn, xem trạng thái/điều khoản/phí.
5. Hệ thống khóa máy, nhận trả trước, chuẩn bị guest và workspace theo lựa chọn.
6. Chuẩn bị xong mới chuyển sang quyền sử dụng theo state machine được duyệt; đo thời gian chờ.
7. Khách dùng ứng dụng streaming, nhận cảnh báo thời gian/sync.
8. Kết thúc: ngừng input, checkpoint dữ liệu đã ghi, báo bản cloud được xác nhận, thu hồi quyền và reset.
9. Tiền theo refund/settlement/dispute; host không được giữ dữ liệu hoặc cloud credentials để ép khách trả thêm.

Giữ trạng thái tài chính, truy cập và đồng bộ dữ liệu tách biệt. “Đã tất toán” không có nghĩa “đã lưu cloud”; “đã upload” không có nghĩa “đã xác minh phiên bản”.

## 4. Thời gian đề xuất cho pilot

| Nội dung | Đề xuất để thử | Vì sao |
| --- | --- | --- |
| Khoảng host đăng nhận thuê | Ít nhất 4 giờ liên tục | Tránh nguồn cung bật/tắt quá ngắn |
| Gói thương mại pilot | Tối thiểu 30 phút, bước 15 phút | Cân bằng công chuẩn bị và chi phí phiên |
| Gói tối đa ban đầu | 2 giờ, chỉ nhận nếu còn đủ cửa sổ | Giới hạn exposure khi chưa có dữ liệu ổn định |
| Biên chuẩn bị/đồng bộ | Dự trù tổng 15 phút ngoài giờ dùng | Cần đo để xác định giá và hạn, không hứa luôn đủ |
| Demo UniHack | Có thể 15 phút testnet, ghi rõ khác pilot | Dễ quay; không đổi timer âm thầm |
| Host maintenance | Chặn phiên mới trước, hoàn thành phiên đã nhận | Không cắt ngang khách để host dùng máy |

Mọi giá trị trên chưa duyệt, không phải chuẩn ngành. Chỉ hiển thị gói thực sự còn đủ thời gian chuẩn bị + dùng + kết thúc. Tác vụ nhiều dữ liệu có thể cần biên khác; không nhận rồi đẩy khách vượt giờ host.

Cam kết là quy tắc vận hành, không phải website có thể ngăn mọi mất điện. Host nhóm ổn định có Ethernet, nguồn dự phòng phù hợp và lịch bảo trì; không tự yêu cầu mua UPS khi chưa có chính sách/budget.

## 5. Cọc và tiền

Tách ba khoản:

- Tiền thuê khách trả trước: giữ theo booking; hoàn/chi trả đúng quy tắc.
- Host bond: cọc cam kết của host, nếu được duyệt; tách khỏi doanh thu và phí nền tảng.
- Storage: trả theo dung lượng/thời gian/quota rõ ràng; không mặc nhiên miễn phí sau thuê.

Đề xuất ưu tiên host bond trước, chưa thu cọc tài sản của renter trong MVP. Guest có thể reset nên không nên đặt phí phạt mơ hồ cho “hỏng phần mềm”.

Cọc host dựa trên giá trị tối đa các phiên đang nhận và mức bồi hoàn đã công bố, không ấn định số VND/AVAX khi chưa có giá và chi phí. Trước mỗi booking khóa phần exposure; không nhận thêm nếu bond khả dụng thiếu. Rút chỉ phần không bị khóa bởi phiên/khiếu nại theo thời hạn hữu hạn.

Không triển khai slash tự động từ heartbeat hoặc để admin tùy ý tịch thu. Xem [chính sách dự thảo](MARKETPLACE_POLICIES_DRAFT.md).

## 6. Tìm máy và AI tư vấn

Bộ lọc cứng luôn có: ứng dụng/OS, CPU/RAM/GPU/VRAM, vùng mạng, giá, thời gian còn nhận thuê, trạng thái kiểm tra, support workspace và compatibility.

AI là tính năng có thể thêm sau core flow; người dùng đã đề nghị nên được phép nghiên cứu, chưa có quyết định đưa vào MVP.

AI hỏi mục đích, phần mềm/phiên bản, quy mô dự án, thời lượng và ngân sách; chuyển thành bộ lọc cấu trúc. Server lấy catalog thật, kiểm tra constraint rồi trả tối đa vài lựa chọn với lý do. AI không tự tạo cấu hình, giá, FPS hay listing không tồn tại.

Không gửi file dự án, credential, thông tin định danh hoặc nội dung phiên cho model để tư vấn cấu hình. Listing/host text là dữ liệu không tin cậy, không phải chỉ dẫn cho AI. AI không có quyền đặt thuê, ký ví, sửa quota, cấp route hoặc đọc workspace.

Nếu cần báo hiệu năng ứng dụng, dùng benchmark đã đo cho template/cấu hình đó và nêu độ cũ; không hứa “chạy mượt” chỉ từ tên GPU.

## 7. Streaming

Đề xuất thử Sunshine/Moonlight native trước; nếu cần browser, đánh giá Selkies cho Linux hoặc giải pháp Windows/browser có license phù hợp. [Nghiên cứu streaming](STREAMING_RESEARCH.md) chưa có benchmark dự án.

Host agent điều phối enrollment, readiness, pair/grant, heartbeat, freeze/revoke và reset; không tự viết codec. Server không đưa API quản trị Sunshine/gateway ra browser.

Sunshine/Parsec không tự tạo môi trường thuê riêng. Dùng guest sạch hoặc máy chuyên dụng; virtual monitor/tài khoản Windows phụ không được coi là isolation đủ cho mã khách không tin cậy. GPU passthrough cần spike riêng trên thiết bị cụ thể.

## 8. Cloud workspace

Hai chế độ:

- Không lưu cloud: guest tạm, khách tự export trước khi hết phiên; không hứa khôi phục sau reset.
- Lưu workspace: chỉ thư mục dự án/thiết lập được chọn, lưu ngoài máy host, có version/last saved, quota và retention; phiên sau khôi phục trên môi trường tương thích.

MVP đề xuất chứng minh portability của một project/file giữa hai host tuần tự. Không hứa di chuyển nguyên Windows, game cài, giấy phép hoặc RAM/app đang chạy. Chi tiết: [CLOUD_WORKSPACES](CLOUD_WORKSPACES.md).

## 9. Bảo mật hai chiều và giới hạn

Khách khỏi host data: guest riêng, không mount disk/home/clipboard cá nhân hoặc route LAN; giới hạn quyền, egress và reset kiểm chứng. Không cấp guest host root/Docker socket/raw disks.

Host khỏi khách data: private storage, scoped grant, không metadata định danh, hạn credential, versioning và giới hạn cloud. Nhưng host quản trị máy vật lý có thể quan sát plaintext/input/memory khi khách xử lý trên máy đó. VM, TLS và disk encryption không tự loại trừ quyền này.

Ví/tài khoản chính và ký giao dịch chỉ trên thiết bị riêng của khách. Không khuyến khích đăng nhập email chính, cloud drive cá nhân, tài khoản ngân hàng hoặc đưa seed/API key lên desktop thuê.

P2P có thể lộ địa chỉ IP mạng của peer. Nếu yêu cầu hai bên không thấy IP nhau, phải khảo sát relay phù hợp, ẩn signaling nhạy cảm và cân nhắc chi phí/độ trễ. Relay không ngăn host đọc dữ liệu đang xử lý.

Nền tảng cũng là bên cần tin cậy khi quản lý auth/cloud/keys. Nếu dùng mã hóa do server quản lý, không quảng cáo “nền tảng không thể đọc file”. Chỉ cung cấp mức bảo mật thực tế đã thử.

## 10. Tách mốc triển khai để không quá tải

| Mốc | Phạm vi đề xuất |
| --- | --- |
| A — nền kỹ thuật | Một host, guest sạch, streaming, grant/revoke/reset qua hai mạng |
| B — marketplace thật | Account, host approval, commitment window, tìm máy, booking và escrow Fuji |
| C — portability | Hai host tuần tự, workspace một thư mục, version/restore, grant đúng user |
| D — vận hành tiền | Chính sách, refund có bằng chứng; bond chỉ sau đặc tả riêng |
| E — tư vấn | AI chỉ đọc catalog, benchmark và bộ lọc, không quyền giao dịch |

Đề xuất bài thi có A+B và một luồng C nhỏ nếu đủ thời gian. AI/bond hiển thị roadmap khi chưa triển khai; không đưa nút hoạt động giả vào demo.

## 11. Ảnh hưởng đến đặc tả cũ

- D03 Linux-only, D04 lịch, D05 giá/thời lượng, D09 no-persistence và D11 Guacamole cần xem lại.
- Bản CONTRACT_SPEC hiện chưa có bond/slashing, chỉ fixed-price escrow; không tuyên bố đã hỗ trợ đặt cọc host hay tính phí phút thực dùng.
- DATA_MODEL/ARCHITECTURE cần bổ sung commitment, policy_version, workspace/version/lease/grants và quyền sync trước code phần liên quan.
- Contract cũ khóa machineKey tới khi tiền terminal. Nếu muốn máy nhận khách mới trong lúc booking cũ tranh chấp, phải đặc tả lại resource lease tách money state và kiểm tra không double grant; không tự gỡ occupancy.
- Bản MVP 0.1 là nền đề xuất cũ; chưa được scaffold theo đó khi yêu cầu mới còn chưa chốt.

## 12. Nguồn và giả định

Số giờ, gói, cọc, bồi thường, quota và kế hoạch là đề xuất dự án, không sao chép thành quy tắc BTC hay pháp luật. Nguồn kỹ thuật chính thức nằm trong STREAMING_RESEARCH và CLOUD_WORKSPACES. Chưa có kiểm thử hạ tầng, security audit hoặc policy thương mại được công bố.
