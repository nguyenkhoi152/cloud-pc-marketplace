# Đặc tả RentalEscrow — bản cần duyệt

DRAFT, chưa có Solidity hoặc contract deploy. Nếu thay quy tắc tiền phải cập nhật APPROVAL, MVP và tests trước.

Đây là escrow fixed-price 0.1. [Thiết kế 0.2](PLATFORM_DESIGN_V02.md) đang cân nhắc host bond, refund theo sự cố và resource lease độc lập; chưa có đặc tả/hợp đồng cho các phần đó. Không tự ghép slashing hoặc cọc vào state machine dưới đây.

## 1. Mục đích và giới hạn

Một contract không upgrade nhận native AVAX Fuji, giữ tiền cho booking, xử lý xác nhận, timeout, dispute, chia tiền và rút bằng pull payment.

Không có token riêng, không mainnet, không tính phí theo giây và không có proof of desktop quality. Dữ liệu vận hành do operator/arbitrator tin cậy trong demo.

## 2. Role

| Role | Quyền |
| --- | --- |
| Renter | Fund đúng quote của mình, cancel khi Funded, accept khi Active, dispute đúng hạn, withdraw khoản được ghi có |
| Host | Nhận credit; yêu cầu hoàn toàn bộ trước start nếu không phục vụ được; không activate hoặc tự xác nhận chất lượng |
| Quote signer | Ký quote EIP-712 từ reservation hợp lệ; đây là trust boundary của tính khả dụng/giá |
| Operator | Activate khi preflight sẵn sàng; refund trước start; không được tự rút escrow |
| Arbitrator demo | Chia tiền duy nhất cho booking Disputed trong deadline |
| Admin | Quản lý role/pause funding/config cho booking tương lai; không sửa snapshot hoặc quét tiền đang giữ |
| Bất kỳ địa chỉ | Gọi timeout/claim khi đủ điều kiện; người gọi không tự nhận tiền |

Role cần kiểm tra trên contract. Demo có thể một người giữ nhiều ví role nhưng không được mô tả là độc lập hoặc phi tập trung.

## 3. Quote và funding

EIP-712 domain gắn chainId + verifyingContract + tên/phiên bản. Payload tối thiểu:

- bookingId ngẫu nhiên bytes32, machineKey ngẫu nhiên ổn định theo listing.
- renter, host, priceWei, feeBps, treasury.
- durationSeconds, fundBy, activateBy, disputeGraceSeconds, arbitrationTimeoutSeconds.
- signer/config version dùng vô hiệu quote chưa fund sau thay cấu hình.

fund kiểm tra chữ ký signer được cấp quyền, msg.sender=renter, renter khác host, số tiền chính xác và dương, địa chỉ hợp lệ, cấu hình/phiên bản hợp lệ, duration/deadline trong giới hạn, block.timestamp < fundBy, activateBy > fundBy, bookingId chưa dùng và machineKey chưa có booking chưa terminal.

Đóng băng mọi điều khoản trong storage khi fund; đổi config không thay booking đã trả. feeBps/treasury phải khớp cấu hình contract tại funding; giới hạn feeBps <= 10000 và demo 1000 bps.

MVP dùng durationSeconds=900, disputeGraceSeconds=600, arbitrationTimeoutSeconds=86400, activateBy=fundBy+300 và fundBy không quá 600 giây kể từ lúc fund. Contract kiểm tra thời hạn/thời lượng khớp cấu hình được duyệt, không nhận giá trị tùy ý chỉ vì quote có chữ ký. Quote có thể được tạo sớm hơn nên khoảng còn lại khi fund thường ngắn hơn 600 giây.

machineKey là định danh pseudonymous công khai, có thể liên kết các booking; không hash IP hoặc serial rồi gọi đó là ẩn danh. Không phát endpoint/credential/PII.

## 4. State machine tiền

~~~text
Chưa tạo --fund--> Funded --activate--> Active --accept/claimAfterGrace--> Settled
                     |                  |
                     |                  +--openDispute--> Disputed --resolve--> Resolved
                     |                                      |
                     +--cancel/refund/expiry--> Refunded      +--timeout--> Refunded
~~~

Terminal là Settled, Resolved hoặc Refunded. Giải phóng occupancy chain một lần khi terminal; database vẫn phải chờ cleanup.

## 5. Quy tắc từng thao tác

| Thao tác dự kiến | Điều kiện | Kết quả |
| --- | --- | --- |
| fund(quote, signature) | Hợp lệ mục 3, nhận đúng tiền | Funded, khóa machineKey |
| cancelBeforeStart(id) | Renter, state Funded | Credit toàn bộ renter, Refunded |
| refundBeforeStart(id) | Host hoặc operator, state Funded | Credit toàn bộ renter, Refunded |
| refundExpired(id) | Bất kỳ ai, Funded, now >= activateBy | Credit toàn bộ renter, Refunded |
| activate(id) | Operator, Funded, now < activateBy, không pause activation | Active, startedAt=block.timestamp, endAt=startedAt+duration |
| accept(id) | Renter, Active | Credit giá cho host trừ phí; Settled, kể cả khách kết thúc sớm |
| openDispute(id) | Renter hoặc host, Active, now < endAt+grace | Disputed, khóa payout, resolutionDeadline=now+arbitrationTimeout |
| claimAfterGrace(id) | Bất kỳ ai, Active, now >= endAt+grace | Credit host trừ phí; Settled |
| resolve(id, hostGrossWei) | Arbitrator, Disputed, now < resolutionDeadline, 0 <= hostGross <= price | Split credit và Resolved |
| refundUnresolved(id) | Bất kỳ ai, Disputed, now >= resolutionDeadline | Credit toàn bộ renter, Refunded |
| withdraw() | Có credit của msg.sender | Chuyển native AVAX; thất bại giữ nguyên credit |

Tên hàm có thể điều chỉnh lúc code, nhưng role/điều kiện/tiền không tự đổi. Host mở tranh chấp là một trust/griefing vector đã chấp nhận cho demo, không phải bằng chứng khách có lỗi.

Các biên dùng đúng dấu: fund và activate trước deadline; expiry và claim từ deadline; dispute/resolve trước deadline; timeout từ deadline. Transaction ordering trên chain quyết định nếu hai hành động cạnh tranh, không theo lúc người dùng bấm nút.

## 6. Chia tiền

Với phân xử, gọi H là gross host được hưởng, P là giá đã giữ, B là feeBps snapshot:

~~~text
fee = floor(H * B / 10000)
hostCredit = H - fee
renterCredit = P - H
treasuryCredit = fee
hostCredit + renterCredit + treasuryCredit = P
~~~

accept/claim dùng H=P. Refund dùng H=0 và phí=0. Cộng dồn credit nếu một ví nhận nhiều vai trò, không ghi đè. Gas không nằm trong P và không được hoàn.

## 7. Truy cập và on-chain state

Operator chỉ activate sau confirmed funding và preflight. Activate confirmed mới cấp access. Khoảng chờ cấp access sau startedAt phải được đo; nếu lỗi, khách có đường dispute.

accept/openDispute/terminal phát event để worker revoke ngay. Hết endAt cũng phải revoke dù chưa có transaction tất toán. Giới hạn phiên không phụ thuộc khách bấm nút hoặc worker settle kịp.

Contract không tự gọi gateway và không tự gửi timeout transaction. Nếu worker dừng, tiền vẫn có lối thoát qua ví và hàm permissionless đúng hạn; quyền desktop phải có watchdog độc lập.

## 8. An toàn tiền và vận hành

- Checks-effects-interactions, chống reentrancy, pull payment. Không chuyển tiền trực tiếp trong transition booking.
- Balance phải đủ tổng tiền đang giữ + credit chưa rút. Không có admin sweep đối với escrow/credit; nhận tiền ngoài fund không được xem là booking.
- funding pause có thể chặn booking mới; không được khóa cancel/refund/dispute/resolve/timeout/withdraw. Pause activation để chuẩn bị lỗi phải để người dùng refund Funded.
- Role/config changes có event, ảnh hưởng booking tương lai theo quy tắc; không đổi treasury/fee/host của booking đã fund.
- Chữ ký quote không dùng lại ở chain/contract khác; bookingId không được tái sử dụng sau terminal.
- Có cách thực hiện role recovery/config quản trị được ghi deployment; chưa có multisig/timelock thì không quảng cáo đã có.

## 9. Quy tắc arbitration minh bạch

Arbitrator demo xem thông tin sự cố ngoài chain, quyết định H và ghi lý do trong audit riêng trước khi ký resolve. Không đưa file hoặc câu mô tả chứa PII lên chain.

Nếu arbitrator im lặng quá 24 giờ, full refund cho renter. Đây là lựa chọn ưu tiên liveness cho khách, có thể khiến host mất doanh thu dù đã phục vụ. Phải nêu trong UI điều khoản host; chưa dùng chính sách này cho kinh doanh tiền thật.

Sau terminal không mở lại dispute hoặc sửa split. Khi renter accept, UI xác nhận đây là kết thúc thanh toán, không chỉ đóng tab.

## 10. Đối soát và event tối thiểu

Funding, Activated, Refunded, DisputeOpened, Resolved, Settled, CreditWithdrawn và role/config/pause changes cần event đủ để đối soát bằng bookingId, role/địa chỉ công khai và số tiền.

Backend kiểm tra receipt success, đúng chain/contract, event và state, đúng renter/host/quote/price. Client gửi tx hash không đủ. Chống duplicate bằng chain/contract/tx/log index; kiểm tra reorg.

## 11. Bằng chứng cần có

Tests cho mọi transition/role/biên thời gian; invariant bảo toàn tiền; quote replay; occupancy; cancel/activate race; dispute/claim boundary; phân xử trùng; withdraw reentrancy và ví nhận tiền revert; pause vẫn thoát tiền.

Địa chỉ contract, chainId, compiler, cấu hình snapshot, ABI/source hash và deployment tx phải được ghi sau khi deploy thật. Hiện chưa có các giá trị đó.
