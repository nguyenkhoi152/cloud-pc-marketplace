# Cloud PC Marketplace

Hồ sơ triển khai 1.0, ngày 07/11/2026, Asia/Saigon. Tên làm việc tạm thời.

**Có thể bắt đầu triển khai local theo yêu cầu mới nhất của chủ dự án. Hiện chỉ có tài liệu, chưa có ứng dụng chạy.**

Đọc [START_HERE](START_HERE.md) để giao việc cho Claude Code. Codex và Claude dùng chung [AGENTS](AGENTS.md); không tiếp tục các prompt AVAX-only hoặc chờ duyệt toàn bộ từ bản cũ.

## Sản phẩm

Chợ kết nối người có máy với người cần thuê. Host được duyệt và đăng khoảng nhận thuê; khách chọn cấu hình, trả point thử, dùng desktop từ xa và tùy chọn lưu project vào workspace để tiếp tục trên máy khác.

Bản demo: PC Point (PCP) trên Avalanche Fuji, escrow theo gói, Sunshine/Moonlight làm baseline, workspace theo project. Token thử không có giá trị tiền thật; không có mua/bán/rút VND trong MVP.

## Đầu vào cho agent

| File | Dùng để làm gì |
| --- | --- |
| [START_HERE](START_HERE.md) | Thứ tự đọc và prompt bắt đầu |
| [Quyền và mặc định](docs/APPROVAL.md) | Phạm vi được bắt đầu, mặc định kỹ thuật, phần cần đầu vào ngoài |
| [MVP](docs/MVP.md) | Tính năng và điều kiện nghiệm thu |
| [Kiến trúc](docs/ARCHITECTURE.md) | Thành phần, stack và deployment boundaries |
| [Dữ liệu/API](docs/DATA_MODEL.md) | Schema, auth, đồng thời, jobs và endpoints |
| [Contract](docs/CONTRACT_SPEC.md) | PCP, escrow, quote, refund và dispute |
| [Point](docs/POINTS_AND_PAYMENTS.md) | UX point, gas, nguồn tài trợ và x402 |
| [Remote](docs/REMOTE_ACCESS.md) | Agent, pairing, revoke và watchdog |
| [Workspace](docs/CLOUD_WORKSPACES.md) | Checkpoint, restore, token và tenant isolation |
| [Bảo mật](docs/SECURITY.md) | Trust boundaries và giới hạn bảo vệ hai bên |
| [Chính sách demo](docs/MARKETPLACE_POLICIES_DRAFT.md) | Cam kết host, sự cố, cọc và refund |
| [Privacy demo](docs/PRIVACY_POLICY_DRAFT.md) | Dữ liệu, providers, retention và quyền |
| [Kiểm tra](docs/TEST_PLAN.md) | Tests và bằng chứng cần có |
| [Lộ trình](docs/DEVELOPMENT_GUIDE.md) | Các mốc và cách tiếp tục khi thiếu hạ tầng |
| [Workflow](docs/AGENT_WORKFLOW.md) | Một writer, một reviewer và bàn giao |
| [Tiến độ](docs/PROGRESS.md) | Trạng thái thực tế để phiên sau tiếp tục |
| [Repo tham khảo](docs/REPO_REFERENCE.md) | Phần học từ SenpAI, không sao chép toàn bộ |
| [Nguồn](docs/SOURCES.md) | Tài liệu chính thức và mức xác minh |
| [Bài nộp](docs/SUBMISSION.md) | Repo, slide, video và deadline |
| [Sản phẩm](docs/PRODUCT.md) | Khách hàng và business model |

PLATFORM_DESIGN_V02, STREAMING_RESEARCH và POLICY_REFERENCE_REVIEW là tài liệu đọc thêm, không có quyền ghi đè đặc tả 1.0. Thư mục archive và các ZIP cũ chỉ giữ lịch sử.

## Mặc định demo

- Host cam kết cửa sổ ít nhất 4 giờ; chỉ thuê tức thời, một booking đang giữ máy.
- Gói demo 15 phút, 20 PCP, phí 10% phần gross trả host. Pilot thương mại chưa triển khai.
- PCP có 18 decimals, token chuyển hạn chế qua escrow; AVAX Fuji chỉ trả gas.
- Cloud: một project nhỏ, tối đa 100 MiB tính cả version, một writer, tối đa 3 checkpoint thành công.
- AI tư vấn và host bond có thiết kế/roadmap; chỉ làm sau core flow, không có cash-out thật.

Đây là mặc định cấu hình để code có thể tiến hành; chủ dự án chưa xác nhận giá/thời hạn thương mại hoặc license của một máy cụ thể.

## Hiện trạng và lệnh chạy

Chưa có package.json, script dev/build/test, migrations hoặc Solidity. Không chạy lệnh dự án dự đoán từ README cũ.

Mốc đầu tạo scripts cần thiết, ghi đúng thư mục và lệnh vào README trước khi chạy. Sau đó thay mục này bằng hướng dẫn đã kiểm chứng. Không ghi giả URL deploy, contract address hoặc kết quả kiểm tra.

## Phạm vi bàn giao

Bộ Markdown này phục vụ Claude bắt đầu code local. Chưa cài dependency ứng dụng, chưa cấu hình PC, chưa có Supabase/cloud project, chưa deploy Fuji hoặc web, chưa thu tiền hay công bố điều khoản thương mại.

Bản trước khi hợp nhất được giữ trong ZIP backup tại deliverables ở checkout gốc. Gói handoff chỉ gồm tài liệu hiện hành để tránh agent đọc nhầm lịch sử.
