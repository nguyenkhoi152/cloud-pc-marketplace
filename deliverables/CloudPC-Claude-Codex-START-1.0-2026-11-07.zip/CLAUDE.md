# Claude Code — điểm vào triển khai

Đọc [AGENTS](AGENTS.md), [START_HERE](START_HERE.md), [README](README.md), [quyền và mặc định](docs/APPROVAL.md), [MVP](docs/MVP.md) và [PROGRESS](docs/PROGRESS.md).

Người dùng đã yêu cầu chuẩn bị để Claude bắt đầu triển khai local. Làm theo prompt M1 trong START_HERE; không dừng để xin duyệt lại toàn bộ tài liệu hoặc chỉ tóm tắt kế hoạch.

Chỉ một agent sửa checkout. Không tự deploy/cấu hình PC/thuê cloud; thiếu đầu vào bên ngoài thì tiếp tục phần local độc lập và ghi đúng blocker. Quy ước chung chỉ có AGENTS.md.
