# Cloud PC Marketplace — hồ sơ chuẩn bị UniHack

Ngày soạn: 07/11/2026, giờ Việt Nam. Tên làm việc tạm thời; chưa chốt thương hiệu.

**Trạng thái: DRAFT — CHỜ CHỦ DỰ ÁN DUYỆT. Chưa được phép bắt đầu triển khai ứng dụng từ bộ tài liệu này.**

## Ý tưởng

Người có máy tính đăng máy và khung giờ có thể cho thuê; người cần máy chọn gói, đặt tiền, truy cập desktop từ xa và kết thúc phiên. Nền tảng quản lý đặt thuê, quyền truy cập, thanh toán và khiếu nại; thu phí trên phiên hoàn tất.

Tầm nhìn có học tập/lập trình, gaming và GPU Studio. Bản thi đề xuất chỉ làm một trường hợp học tập/lập trình trên một máy chuyên dụng đã duyệt. Đây là marketplace có nguồn cung từ chủ máy, không phải nền tảng tự mua sẵn toàn bộ máy.

## Đọc và duyệt

1. Đọc [Phiếu duyệt](docs/APPROVAL.md) trước.
2. Đọc [Ý tưởng và kinh doanh](docs/PRODUCT.md), [MVP](docs/MVP.md).
3. Đọc [Kiến trúc](docs/ARCHITECTURE.md), [Giới hạn và bảo mật](docs/SECURITY.md) nếu muốn kiểm tra tính khả thi.
4. Gửi quyết định duyệt hoặc sửa trong chat. Agent cập nhật hồ sơ duyệt theo lời người dùng; không tự đánh dấu đã duyệt.

## Bản đồ tài liệu

| File | Nội dung chính |
| --- | --- |
| [AGENTS.md](AGENTS.md) | Quy ước chung cho Codex và Claude Code |
| [CLAUDE.md](CLAUDE.md) | Điểm vào cho Claude Code |
| [APPROVAL](docs/APPROVAL.md) | Các lựa chọn cần duyệt, quyền triển khai và điều kiện mở mốc |
| [PRODUCT](docs/PRODUCT.md) | Khách hàng, giá trị, cạnh tranh và mô hình thu phí |
| [MVP](docs/MVP.md) | Vai trò, màn hình, phạm vi và nghiệm thu |
| [ARCHITECTURE](docs/ARCHITECTURE.md) | Thành phần, công nghệ đề xuất và luồng hệ thống |
| [DATA_MODEL](docs/DATA_MODEL.md) | Dữ liệu, quy tắc đồng thời và hợp đồng API dự kiến |
| [CONTRACT_SPEC](docs/CONTRACT_SPEC.md) | Giữ tiền, phân quyền, hoàn tiền và tranh chấp |
| [REMOTE_ACCESS](docs/REMOTE_ACCESS.md) | Máy thật, gateway, kết nối và thu hồi quyền |
| [SECURITY](docs/SECURITY.md) | Mô hình tin cậy, bí mật, dữ liệu và rủi ro |
| [TEST_PLAN](docs/TEST_PLAN.md) | Các kiểm tra có ý nghĩa và bằng chứng nghiệm thu |
| [DEVELOPMENT_GUIDE](docs/DEVELOPMENT_GUIDE.md) | Mốc thực hiện, lịch đến hạn thi và deploy |
| [AGENT_WORKFLOW](docs/AGENT_WORKFLOW.md) | Cách bàn giao Claude/Codex và prompt theo mốc |
| [PROGRESS](docs/PROGRESS.md) | Tiến độ thật, kiểm tra đã/chưa làm |
| [SUBMISSION](docs/SUBMISSION.md) | README cuối, slide, video và yêu cầu nộp |
| [SOURCES](docs/SOURCES.md) | Nguồn chính thức, ngày kiểm tra và điểm chưa xác minh |

## Trạng thái kỹ thuật thực tế

- Chỉ có tài liệu; chưa có mã ứng dụng, package manifest, migration hay smart contract.
- Chưa có máy cho thuê được xác nhận; chưa kiểm tra remote desktop, khả năng thu hồi kết nối hoặc GPU.
- Chưa có repo GitHub, URL triển khai, hợp đồng Fuji hoặc giao dịch demo được xác minh trong phiên chuẩn bị này.
- Các thư mục web/, contracts/, supabase/, gateway/, worker/ trong tài liệu là cấu trúc đề xuất, chưa tồn tại.
- Chưa có lệnh build/test/dev của dự án để chạy. Agent phải tạo script và ghi cách dùng trước khi chạy kiểm tra.

## Bước tiếp theo

Chủ dự án duyệt [APPROVAL](docs/APPROVAL.md). Sau đó làm mốc M0: khảo sát công cụ và thử desktop thật qua hai mạng, kiểm tra cấp/thu hồi quyền. Chỉ đi tiếp sau khi có bằng chứng, không thay bằng ảnh desktop hoặc bộ đếm giả.

## Lịch sử

Ý tưởng UniAct đã được thay bằng Cloud PC Marketplace theo yêu cầu ngày 07/11/2026. Sáu tài liệu UniAct cũ được sao lưu nguyên nội dung và kiểm tra hash tại [kho lưu trữ](docs/archive/README.md). Không dùng các quy tắc CTXH/UACT của bản cũ cho sản phẩm mới.

Thông tin cuộc thi và công nghệ là dữ liệu tham khảo từ [nguồn](docs/SOURCES.md); quyết định triển khai thuộc hồ sơ duyệt và chỉ dẫn trực tiếp của chủ dự án.
