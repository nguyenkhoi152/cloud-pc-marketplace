# Dữ liệu, đồng thời và API dự kiến

DRAFT. Tên bảng/API là hợp đồng thiết kế, chưa tồn tại.

## 1. Mô hình dữ liệu

| Bảng | Trường chính đề xuất |
| --- | --- |
| profiles | user_id, display_name, trạng thái tài khoản; role không tự sửa |
| host_profiles | user_id, approval_status, approved_by, approved_at |
| wallet_challenges | user_id, wallet, domain, chain_id, nonce_hash, expires_at, consumed_at |
| wallet_links | user_id, address_normalized, chain_id, verified_at |
| machines | id, owner_id, status, specs_declared, specs_verified, verified_at, availability_until, heartbeat_at, active_booking_id |
| machine_private_config | machine_id, credential_ref, endpoint_ref; chỉ server/worker |
| bookings | id UUID ngẫu nhiên, onchain_id bytes32 ngẫu nhiên, machine_id, renter_id, quote_snapshot, fund_by, activate_by, money_status, access_status |
| quotes | quote_id, booking_id, signer_version, payload_hash, signature, expiry; snapshot bất biến |
| chain_events | chain_id, contract, tx_hash, log_index, block_number, block_hash, event_type, booking_id |
| remote_sessions | booking_id, provider_session_ref, user_id, expires_at, grant/revoke/reset status; không public token |
| incidents/disputes | booking_id, actor, lý do, evidence_ref riêng, chain status, quyết định |
| outbox_jobs | idempotency_key, type, booking_id, payload_ref, attempts, available_at, locked_until, result |
| audit_logs | actor/role, action, resource_id, timestamp, kết quả đã lọc secret |

Mật khẩu và khóa không lưu dạng plain text trong bảng hoặc JSON quote. credential_ref trỏ tới secret store đã cấu hình; chọn giải pháp khi triển khai. Thông tin cá nhân và bằng chứng giữ ngoài chain.

## 2. Các trạng thái độc lập

Máy: Draft → PendingReview → Approved; có thể Suspended/Offline/Draining. Available là trạng thái suy ra từ approved + online + đủ giờ + chưa có lock + cleanup đạt.

Booking tiền: Reserved (DB, chưa có on-chain booking) → Funded → Active → Settled, hoặc Refunded, hoặc Disputed → Resolved/Refunded.

Truy cập: NotGranted → Preparing → Ready → Granted → Revoking → Revoked → Resetting → ResetVerified; Failed/Unknown giữ máy khóa.

Không suy ra AccessGranted chỉ vì money_status=Active. Không suy ra máy Available chỉ vì tiền Settled. Thời gian Active kết thúc vẫn có thể chờ grace/dispute, máy giữ khóa đến khi booking terminal và cleanup đạt.

## 3. Đặt máy nguyên tử

- Một transaction server khóa hàng machines, kiểm tra quyền/khả dụng, kiểm tra active_booking_id và tạo reservation/quote snapshot, outbox.
- Có unique/constraint phù hợp cho một live reservation/booking trên một máy. Admin gắn một thiết bị enrollment với một machineKey chuẩn; không duyệt nhiều listing đang hoạt động cho cùng một máy vật lý để vượt lock. Phải chứng minh bằng hai request đồng thời, không chỉ dựa UI.
- Backend lấy renter từ session, host từ máy, giá từ config/server; client không được truyền giá hoặc vai trò có hiệu lực.
- Trước ký quote, kiểm tra availability_until >= activateBy + durationSeconds + 60 giây cleanup buffer đề xuất. Khoảng giờ chủ máy khai không thay thế heartbeat thực tế.
- Không tự ký quote mới cho máy còn booking trước hoặc trạng thái chain chưa đối soát.
- Contract cũng khóa occupancy theo machineKey khi fund; cần cả hai lớp.

## 4. Giữ chỗ hết hạn và chain race

Hạn giữ chỗ demo tối đa 10 phút, quote có fundBy tương ứng. Contract chỉ nhận funding khi block.timestamp < fundBy.

Khi DB thấy hết giờ, chưa được giải phóng ngay: đợi nguồn chain đã bắt kịp hạn quote theo chính sách xác nhận, đối soát booking ID và occupancy, xử lý receipt đang pending. Nếu không xác minh được, giữ khóa.

Nếu fund đã thành công đúng hạn nhưng worker chậm, cập nhật Funded và tiếp tục; không tạo booking khác. Giao dịch fund bị include sau hạn phải revert; gas vẫn do người gửi chịu.

On-chain terminal chưa đủ giải phóng DB lock: phải revoke + reset được xác nhận. Cleanup thất bại thì chuyển máy unavailable và yêu cầu vận hành.

## 5. RLS và server authorization

- Public chỉ thấy listing Approved và phần specs/anonymized availability an toàn.
- Renter chỉ thấy booking, tranh chấp và phiên của mình.
- Host chỉ sửa listing nháp/config thương mại của máy mình; sửa cấu hình ảnh hưởng chất lượng cần duyệt lại. Không sửa renter, price snapshot, payment status hoặc gateway refs.
- Admin được cấp ngoài client; audit mọi duyệt máy và phân xử.
- Private config, outbox, chain events ingestion và audit writes chỉ server/worker có quyền cần thiết.
- Service-role vượt RLS nên API dùng service-role phải tự kiểm tra actor và phạm vi; không lấy đây làm lý do bỏ kiểm tra server.

## 6. API dự kiến

| API | Quyền và điều kiện |
| --- | --- |
| GET /api/machines, GET /api/machines/:id | Public; lọc listing/field trước khi trả |
| POST /api/wallet/challenge, POST /api/wallet/verify | User đăng nhập; nonce một lần, domain/chain/expiry, signature server verify |
| POST /api/host/machines, PATCH /api/host/machines/:id | Host đã duyệt, đúng owner; optimistic version khi sửa |
| POST /api/admin/machines/:id/approve | Admin, bằng chứng kiểm tra, audit |
| POST /api/bookings | Renter đã link wallet; atomic lock; idempotency key |
| GET /api/bookings/:id | Renter/owner/admin tùy field; không lộ private endpoint |
| POST /api/bookings/:id/reconcile | Renter/admin; chỉ trigger kiểm tra chain, client tx hash là gợi ý |
| POST /api/bookings/:id/access | Đúng renter; confirmed Active, chưa end/dispute/terminal, guest/gateway ready |
| POST /api/bookings/:id/end | Renter; revoke trước/đồng thời workflow, hướng dẫn xác nhận contract; không tự ký thay |
| POST /api/bookings/:id/incidents | Renter/host theo phạm vi; báo backend chưa phải dispute on-chain |
| POST /api/admin/disputes/:id/prepare-resolution | Admin chuẩn bị split; transaction do ví arbitrator ký, kiểm tra kết quả chain |
| POST /api/internal/hosts/:id/heartbeat | Connector đã enrollment, định danh máy, chống replay |

Các giao dịch fund/cancel/accept/dispute/claim/withdraw gọi contract từ ví đúng role, không phải API tự ý ký thay khách. Worker chỉ ký chức năng operator được cấp.

## 7. Quy ước API và lỗi

Mutations xác thực origin/CSRF phù hợp session, schema validate, rate limit, giới hạn body; idempotency key ràng buộc user + hành động + payload hash. Key trùng với payload khác phải bị từ chối.

Lỗi phân biệt: unauthorized, forbidden, machine_unavailable, reservation_expired, wrong_network, funding_pending, funding_reverted, access_not_ready, access_revocation_pending, dispute_requires_chain_confirmation.

Mã lỗi ổn định cho UI; log nội bộ dùng correlation ID, không log token/secret/request body nhạy cảm.

## 8. Thời gian, số tiền và đối soát

Timestamps DB UTC; UI Asia/Saigon. Deadline on-chain dùng block time, UI clock chỉ tham khảo. AVAX lưu wei dạng integer an toàn, không JavaScript floating point.

Unique event: chain_id + contract + tx_hash + log_index. Cập nhật booking theo transition hợp lệ, chống event trễ quay ngược terminal. Khi block hash không khớp, đánh dấu cần đối soát thay vì tiếp tục cấp quyền.

## 9. Retention đề xuất

Guest reset sau phiên; không promise khôi phục. Token/credential ngắn hạn xóa hoặc hủy sau revoke. Log vận hành và evidence giữ tối đa 30 ngày cho demo, quyền truy cập giới hạn; chưa có chính sách retention thương mại được duyệt. Blockchain công khai không xóa được nên chỉ dùng ID ngẫu nhiên và dữ liệu tiền tối thiểu.
