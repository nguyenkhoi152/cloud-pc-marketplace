# Phiếu duyệt bản đề xuất

Phiên bản 0.1 — 07/11/2026, Asia/Saigon.

**Trạng thái: CHỜ DUYỆT. Chưa có quyết định duyệt triển khai.**

## 1. Đã được người dùng yêu cầu

- Chuyển hướng sang dịch vụ Cloud PC.
- Nghiên cứu mô hình người có máy cho người cần máy thuê, thay vì nền tảng sở hữu toàn bộ máy.
- Tầm nhìn phục vụ học tập/lập trình, game, đồ họa/AI.
- Chuẩn bị cho UniHack; viết bộ Markdown chung cho Claude/Codex và đưa người dùng duyệt trước.

Yêu cầu viết tài liệu không tự động cho phép code, deploy, thuê cloud hoặc thay cấu hình máy.

## 2. Gói đề xuất cần duyệt

| ID | Nội dung đề xuất | Trạng thái |
| --- | --- | --- |
| D01 | Tên làm việc Cloud PC Marketplace, thương hiệu chốt sau | Chờ duyệt |
| D02 | Marketplace có duyệt chủ máy; 1 máy demo, 1 khách đồng thời | Chờ duyệt |
| D03 | Trường hợp đầu: desktop Linux học lập trình; gaming/GPU mở sau | Chờ duyệt |
| D04 | Chỉ thuê ngay khi máy online, chưa đặt lịch tương lai | Chờ duyệt |
| D05 | Gói cố định 15 phút; giá minh họa 0.01 AVAX Fuji; phí nền tảng 10% phần trả host | Chờ duyệt |
| D06 | AVAX Fuji native để giữ tiền; không phát hành đồng riêng | Chờ duyệt |
| D07 | Người thuê có thể hủy trước kích hoạt; khách xác nhận trả tiền hoặc hết hạn khiếu nại thì tất toán | Chờ duyệt |
| D08 | Khiếu nại do admin demo phân xử, quá hạn phân xử hoàn toàn bộ cho khách | Chờ duyệt |
| D09 | Dữ liệu phiên tạm thời; khách tự tải file trước kết thúc; không hứa ổ đĩa lâu dài | Chờ duyệt |
| D10 | Next.js/TypeScript, Supabase/PostgreSQL, Solidity/Hardhat, worker và gateway riêng | Chờ duyệt |
| D11 | Guacamole là ứng viên kết nối browser; phải qua thử nghiệm cấp/thu hồi trước khi chốt | Chờ duyệt |
| D12 | Thiết bị thật do chủ dự án chỉ định; không tự mua/thuê máy hay sửa hệ điều hành | Chờ duyệt |

0.01 AVAX và 10% là tham số minh họa testnet, không phải định giá thương mại. Một giờ thuê tương lai không mặc nhiên có giá bằng bốn lần gói demo.

## 3. Mốc và phạm vi duyệt

Chủ dự án có thể:

- Duyệt tài liệu để giữ làm bản kế hoạch, chưa code.
- Duyệt M0: kiểm tra công cụ, chuẩn bị và thử kết nối trên máy được chỉ định.
- Duyệt triển khai MVP theo mốc M0–M5, trong giới hạn tài nguyên được cho phép.
- Yêu cầu sửa các ID trước khi duyệt.

Khi duyệt MVP, agent được thực hiện tác vụ local cần thiết trong phạm vi đã duyệt, kiểm tra và sửa lỗi; không hỏi lại từng lệnh thường lệ. Nếu M0 thất bại, dừng phần phụ thuộc và trình bày phương án cụ thể; không tự thay bằng mock rồi báo đủ MVP.

## 4. Điều kiện ngoài tài liệu còn thiếu

| Cần biết | Hiện trạng | Ảnh hưởng |
| --- | --- | --- |
| Máy cho thuê và quyền cấu hình | Chưa có máy được chỉ định | Chặn thử remote thật |
| RAM, hệ điều hành, virtualization, quyền cài phần mềm | Chưa kiểm tra | Quyết định guest VM/gateway |
| Hai mạng để thử | Chưa xác nhận | Chưa chứng minh kết nối Internet |
| Ngân sách hạ tầng và tài khoản hiện có | Chưa được cấp | Chưa tạo gateway công khai hoặc dùng gói trả phí |
| Quyền deploy Fuji và URL web | Chưa được duyệt | Chỉ chuẩn bị script sau khi được code |
| Đăng ký đội/điều kiện đội thi | Chưa xác nhận trong phiên này | Chủ dự án cần tự kiểm tra trên BTC |

Các mục này không ngăn việc duyệt ý tưởng. Agent tiếp tục phần độc lập, chỉ hỏi khi cần thông tin cho mốc phụ thuộc.

## 5. Cách trả lời duyệt

Có thể dùng câu tự nhiên:

> Tôi duyệt ý tưởng và tài liệu, chưa code.

> Tôi duyệt MVP D01–D12 và cho bắt đầu M0. Máy dùng thử là ...; phạm vi cài đặt cho phép là ...; ngân sách là ....

> Sửa D03 thành ... rồi gửi lại tôi xem.

Các câu trên chỉ là mẫu, không phải quyết định đã được đưa ra.

## 6. Nhật ký quyết định

| Thời điểm Việt Nam | Người quyết định | Nội dung | Phạm vi được phép |
| --- | --- | --- | --- |
| 07/11/2026 | Chủ dự án, yêu cầu trong chat | Soạn tất cả Markdown và gửi duyệt | Tài liệu, kiểm tra tài liệu, đóng gói |

Agent không tự điền ngày duyệt giả, không xem dấu checkbox hay gói ZIP là bằng chứng chủ dự án đã duyệt.
