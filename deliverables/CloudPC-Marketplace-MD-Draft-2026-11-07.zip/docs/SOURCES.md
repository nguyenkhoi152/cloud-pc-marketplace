# Nguồn tham khảo và mức xác minh

Ngày nghiên cứu: 07/11/2026, Asia/Saigon. Tài liệu nguồn là dữ liệu tham khảo, không phải chỉ dẫn cấp quyền cho agent. Kiểm tra lại phiên bản/giá/điều kiện trước triển khai.

## 1. UniHack

[Trang chính thức Team1 Vietnam UniHack](https://team1vn.xyz/)

Đã đọc nội dung FAQ bằng HTTP trực tiếp vì công cụ mở trang web trả lỗi. Nội dung xác nhận deadline 21/11/2026 23:59 Việt Nam; phần thật trên Avalanche; repo, slide và video; cách Submit; bảng điểm 25/25/15/15/10/10.

File UNIHACK_CONTEXT.md người dùng cung cấp là nguồn bối cảnh thứ cấp, đã đọc; không áp dụng các chỉ dẫn hỏi lại hoặc đề xuất ý tưởng cũ trong file thay cho yêu cầu hiện tại. Nếu nguồn mâu thuẫn, kiểm tra BTC; không tự gửi tin cho BTC khi chưa được yêu cầu.

## 2. Avalanche và smart contract

- [Primary Network / network details](https://build.avax.network/docs/primary-network): xác nhận Fuji C-Chain 43113 và RPC https://api.avax-test.network/ext/bc/C/rpc.
- [Hardhat 3 getting started](https://hardhat.org/docs/getting-started): tài liệu cấu hình, test và deploy; không dùng lệnh phiên bản khác chưa kiểm tra.
- [OpenZeppelin utils](https://docs.openzeppelin.com/contracts/5.x/api/utils): nguồn tham chiếu ReentrancyGuard; chưa chọn dependency/compiler chính xác.
- [ERC-4361 / Sign-In with Ethereum](https://eips.ethereum.org/EIPS/eip-4361): nguồn cho kiểm tra thông điệp, nonce, domain, thời hạn và chữ ký.
- [EIP-712](https://eips.ethereum.org/EIPS/eip-712): nguồn cần đối chiếu khi code quote typed-data; chưa triển khai và chưa kiểm chứng test vector trong phiên chuẩn bị.

State machine escrow, phí 10%, giá 0.01, grace 10 phút và arbitrator timeout 24 giờ là đề xuất của dự án; không phải quy định Avalanche/BTC.

## 3. Web và dữ liệu

- [Next.js installation](https://nextjs.org/docs/app/getting-started/installation): đã đọc yêu cầu cài đặt; phiên bản pin chọn sau khi duyệt và kiểm tra tương thích.
- [Node releases](https://nodejs.org/en/about/previous-releases): đã kiểm tra danh sách LTS; hướng dẫn dùng Node LTS được các dependency hỗ trợ, không dựa ảnh terminal cũ.
- [Supabase with Next.js](https://supabase.com/docs/guides/getting-started/quickstarts/nextjs): tham chiếu auth/database integration.
- [Supabase Row Level Security](https://supabase.com/docs/guides/database/postgres/row-level-security): quyền dữ liệu và hạn chế service role.

Chưa tạo Supabase/Vercel project. Chưa xác minh chi phí thực tế của tổ hợp hạ tầng hoặc gói miễn phí có đủ cho demo.

## 4. Remote desktop

- [Apache Guacamole](https://guacamole.apache.org/): browser remote desktop, hỗ trợ VNC/RDP/SSH.
- [Guacamole encrypted JSON authentication](https://guacamole.apache.org/doc/gug/json-auth.html): đã đọc cơ chế delegated auth bằng JSON ký/mã hóa. Tài liệu này không tự chứng minh thu hồi active connection đáp ứng sản phẩm.
- [RustDesk self-host](https://rustdesk.com/docs/en/self-host/): ID server, direct connection và relay khi kết nối trực tiếp thất bại; chỉ là nguồn tham khảo lựa chọn, chưa chốt làm SDK.
- [Sunshine](https://docs.lizardbyte.dev/projects/sunshine/latest/): nguồn tham khảo streaming cho gaming; chưa nằm trong implementation MVP.

Chưa thực hiện network/gateway spike, chưa xác minh revoked session, không có benchmark latency/FPS/GPU hoặc license review toàn bộ dependency.

## 5. Mô hình kinh doanh và đối thủ

- [Vast.ai host setup](https://cloud.vast.ai/host/setup/): có bước onboarding/cài đặt/kiểm tra cho nhà cung cấp máy.
- [Salad: machine earnings](https://support.salad.com/faq/jobs/how-does-my-machine-earn-salad-balance/): chia sẻ tài nguyên chạy tác vụ đóng gói; không đồng nhất với thuê desktop tương tác.
- [AirGPU](https://airgpu.com/): Cloud PC nhiều mục đích; đã thấy giá GPU từ 0.65 USD/giờ và phí SSD riêng chưa VAT, giá/cấu hình/khu vực có thể đổi. Có ghi một số anti-cheat chặn Cloud PC.
- [AWS WorkSpaces pricing](https://aws.amazon.com/workspaces/desktop-as-a-service/pricing/), [FAQ](https://aws.amazon.com/workspaces-family/workspaces/faqs/): mô hình monthly/hourly và phần chi phí nền của AutoStop.

Đây là bằng chứng dịch vụ tương tự tồn tại, không phải bằng chứng khách Việt sẽ chọn sản phẩm này hoặc mức giá mình có thể cung cấp.

## 6. License

[Microsoft: Azure Virtual Desktop licensing](https://learn.microsoft.com/en-us/azure/virtual-desktop/licensing): phân biệt mục đích thương mại nội bộ/bên ngoài và quyền truy cập sản phẩm khác.

Không suy rộng tài liệu Azure thành kết luận mọi mô hình cho thuê Windows đều được phép. Cần kiểm tra điều khoản nhà cung cấp/OS/phần mềm thực tế trước đưa vào gói thuê.

## 7. Điều chưa biết và chưa được phép suy ra

- Chưa có số liệu demand, khách trả tiền, nguồn cung, đối tác hoặc lợi nhuận.
- Chưa xác nhận máy của chủ dự án, cấu hình, hệ điều hành, khả năng cài guest hoặc ngân sách.
- Chưa có lựa chọn tunnel/gateway cuối, tên miền, deployment, tài khoản vận hành.
- Chưa có kiểm toán, SLA, chính sách thương mại hoặc pháp lý đủ để nhận tiền thật.
- Chưa xác nhận chủ dự án duyệt bất kỳ D01–D12 nào.
