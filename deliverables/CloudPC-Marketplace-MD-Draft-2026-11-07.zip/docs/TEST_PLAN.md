# Kế hoạch kiểm tra và bằng chứng

DRAFT. Mọi hàng hiện là CHƯA CHẠY. Chưa có script ứng dụng, chưa có kiểm thử nào được báo PASS.

## 1. Nguyên tắc

Tạo script tương ứng và hướng dẫn trong README trước khi chạy; dùng phiên bản/công cụ thực tế. Ưu tiên nghiệp vụ tiền, quyền, đồng thời và remote session; không tạo test chỉ để lặp lại implementation hoặc tăng số lượng.

Mỗi kết quả ghi thời gian, phiên bản/commit, môi trường, thao tác, kỳ vọng, thực tế, PASS/FAIL/BLOCKED và bằng chứng đã lọc secret. Screenshot không thay cho receipt hoặc kiểm tra quyền.

## 2. M0 — remote spike

| ID | Tình huống | Điều kiện đạt |
| --- | --- | --- |
| R01 | Khách qua mạng khác | Mở desktop thật, gõ và chạy một chương trình |
| R02 | Revoke khi còn mở desktop | Kết nối hiện tại dừng; đo thời gian |
| R03 | Token/link cũ sau revoke | Không reconnect, kể cả từ tab/thiết bị khác |
| R04 | Hết endAt khi web/worker dừng | Watchdog chặn sử dụng tiếp |
| R05 | Reset rồi khách tiếp theo | Không còn file, process, credential và session trước |
| R06 | Khách thử đường ngoài guest | Không truy cập home/LAN/tài khoản host |
| R07 | Tắt mạng host rồi bật lại | Trạng thái rõ, không tự mở phiên hết hạn |

R02–R04 chưa đạt thì không gọi gateway đã tích hợp hoàn chỉnh.

## 3. Auth, API và dữ liệu

| ID | Tình huống | Điều kiện đạt |
| --- | --- | --- |
| A01 | User tự sửa role hoặc owner ID | Server/RLS từ chối |
| A02 | Host sửa máy/booking host khác | Từ chối, không lộ private fields |
| A03 | Renter mở booking/access người khác | Từ chối ở API lẫn gateway |
| A04 | Hai khách đặt cùng lúc | Chỉ một reservation thành công, không hai quote sống |
| A05 | Đặt lại cùng idempotency key | Không tạo thêm booking; payload khác bị từ chối |
| A06 | Quote/hold hết hạn nhưng receipt đến chậm | Đối soát trước release, không double booking |
| A07 | Giả heartbeat hoặc replay | Từ chối đúng máy/nonce/time |
| A08 | Sửa giá/host/duration từ client | Không thay snapshot hoặc funding terms |
| A09 | Ví sai, nonce cũ/hết hạn, domain sai | Không link hoặc ký quote trái phép |
| A10 | Client có service credential/endpoint private | Không tìm thấy trong response/bundle |

## 4. Contract

| ID | Tình huống | Điều kiện đạt |
| --- | --- | --- |
| C01 | Funding đúng/sai số tiền, chữ ký hoặc renter | Đúng được nhận; sai revert, không đổi occupancy |
| C02 | Quote replay booking/chain/contract | Không dùng lại được |
| C03 | Hai quote cùng machineKey | Không fund đồng thời khi booking trước chưa terminal |
| C04 | Cancel và activate cạnh tranh | Chỉ transition hợp lệ thắng; tiền không được credit hai lần |
| C05 | Activate sai role/đúng hạn/hết hạn | Role và dấu biên đúng đặc tả |
| C06 | Refund trước start/expiry | Credit đủ renter, không thu phí, gọi lặp không cộng |
| C07 | Accept/claimAfterGrace | Chỉ đúng state/role/time, chia tiền đúng |
| C08 | Dispute ngay trước/tại cutoff | Trước được; từ cutoff bị từ chối; claim ngược lại |
| C09 | Resolve/timeout ngay deadline | Split đúng, terminal một lần, refund timeout đủ |
| C10 | Rounding/0%/100% fee trong giới hạn | Tổng credit bằng tiền giữ, không underflow |
| C11 | Một ví nhận nhiều credit roles | Cộng đúng, không overwrite |
| C12 | Withdraw hai lần, reentrancy, recipient revert | Không mất tiền; revert giữ quyền rút |
| C13 | Pause và đổi cấu hình | Booking cũ giữ terms, các lối thoát vẫn dùng được |
| C14 | Admin cố rút tiền còn giữ | Không có đường làm trái đặc tả |

Thêm invariant balance >= escrow outstanding + credit outstanding; xét native AVAX được gửi ngoài fund mà không tạo booking. Fuzz số tiền/deadline/sequence trong phạm vi hợp lệ.

## 5. Chain và worker

| ID | Tình huống | Điều kiện đạt |
| --- | --- | --- |
| W01 | Hủy ký/sai chain/tx revert/tx pending | Không mở desktop hoặc báo thành công nhầm |
| W02 | Tx hash giả/sai contract/event/booking/wallet | Backend từ chối |
| W03 | Worker ingest lại event, retry job | Không cấp phiên, trả tiền hoặc reset trùng gây lỗi |
| W04 | Browser đóng/tải lại giữa funding | Khôi phục từ DB/chain, không bắt trả lại |
| W05 | Active confirmed nhưng grant fail | Incident rõ, có đường dispute; không sửa thành chưa fund |
| W06 | Worker crash giữa revoke/reset | Restart tiếp tục idempotent, máy chưa available sớm |
| W07 | RPC lỗi hoặc block hash thay đổi | Không cấp quyền mới khi chưa chắc chắn; đối soát lại |
| W08 | Terminal nhưng cleanup fail | Máy vẫn khóa dù contract occupancy đã trống |
| W09 | Worker ngừng hết deadline | Người dùng vẫn gọi refund/claim/timeout/withdraw hợp lệ |

## 6. E2E và giao diện

Một host, một renter và admin ở tài khoản riêng. Happy path đi qua đăng máy → duyệt → reserve → fund Fuji → activate → dùng thật → accept → revoke/reset → withdraw → explorer.

Nhánh lỗi: booking khác Funded nhưng không activate → refund; một booking khác Active → dispute → split/timeout. Test local cho 24 giờ bằng điều khiển thời gian; không cần chờ thật để quay video và không thay đổi thời hạn deployment âm thầm.

Kiểm tra trạng thái đang ký, chờ chain, đang chuẩn bị, đang dùng, mất kết nối, hết giờ, đang thu hồi, đang chờ tiền được rút. Nút “Xác nhận hoàn tất và trả tiền” không ghi mơ hồ là “Đóng”.

## 7. Phát hành và bài nộp

Web HTTPS truy cập ngoài mạng dev; auth redirect/origin đúng; host endpoint không public; gateway/worker có health check. Khóa admin/deploy không nằm trong repo/history/bundle/log. CI/build dùng scripts đã có.

Kiểm tra repo/slide/video từ trình duyệt không có quyền của tác giả; private repo cấp đúng tài khoản BTC. Video dùng dữ liệu demo, không credential/seed.

## 8. Báo cáo sau mỗi mốc

~~~text
Mốc / commit:
Môi trường và phiên bản:
Đã chạy (script hoặc thao tác thực tế):
Kết quả và bằng chứng:
Chưa chạy / bị chặn:
Mock còn lại:
Rủi ro còn lại:
Bước tiếp:
~~~
