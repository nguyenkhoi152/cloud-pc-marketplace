# Phạm vi MVP — Cloud PC Marketplace

DRAFT 0.1, 07/11/2026. Chưa được chủ dự án duyệt.

## 1. Một câu mô tả

Chủ máy đã duyệt cho khách thuê tức thời một desktop Linux riêng theo gói 15 phút, giữ tiền AVAX thử trên Fuji và kết thúc bằng tất toán hoặc xử lý lỗi.

## 2. Vai trò

- Khách: xem máy được duyệt và sẵn sàng, liên kết ví, đặt thuê, truy cập phiên của mình, kết thúc, khiếu nại và rút khoản được ghi có.
- Host: đăng hồ sơ máy, khai cấu hình/ứng dụng, bật/tắt nhận phiên mới, xem các booking của máy mình và thu nhập. Không tự duyệt máy hoặc tự xác nhận đã phục vụ để lấy tiền.
- Admin demo: cấp quyền host, duyệt máy sau kiểm tra, quản lý sự cố và phân xử theo đặc tả. Quyền được cấp ở server/contract, không tự chọn trong trình duyệt.
- Operator: dịch vụ backend/worker được cấp quyền kích hoạt trên chain và điều phối gateway; không phải quyền của host.

Một tài khoản có thể được duyệt làm host và cũng thuê máy khác, nhưng cấm đặt máy của chính mình trong demo để tránh nhầm vai trò.

## 3. Phạm vi bắt buộc

1. Đăng nhập qua Supabase Auth; liên kết ví bằng ký thông điệp có nonce/domain/thời hạn.
2. Host tạo listing nháp; admin kiểm tra máy và duyệt.
3. Host khai khoảng sẵn sàng phục vụ; chỉ nhận thuê ngay khi đủ thời gian cho cả activation buffer và gói. Chưa có lịch đặt trước/định kỳ.
4. Tồn tại ít nhất một desktop thật có ứng dụng lập trình; một máy phục vụ một booking.
5. Giữ chỗ nguyên tử ở server, giá đóng băng trong quote, ký quỹ trên Fuji và xác minh receipt.
6. Khi máy/gateway đã sẵn sàng và kích hoạt on-chain được xác nhận, cấp quyền truy cập phiên.
7. Hiển thị thời điểm hết phiên, trạng thái mất mạng và tiền đang được giữ. Bộ đếm chỉ hiển thị, không quyết định quyền hoặc số tiền.
8. Ngắt quyền khi hết thời gian, khi khách kết thúc hoặc khi phiên bị hủy/khiếu nại; chặn cả kết nối đang mở và reconnect.
9. Xác nhận hoàn tất, tất toán theo hạn, hoàn tiền trước kích hoạt, mở tranh chấp và phân xử.
10. Lưu lịch sử và đối soát lại khi tải trang/worker khởi động lại.

## 4. Màn hình

| Màn hình | Nội dung |
| --- | --- |
| Trang giới thiệu/danh sách | Cấu hình đã kiểm tra, ứng dụng, thời gian khả dụng, nhãn testnet |
| Chi tiết máy | Giá gói, giới hạn, chủ máy đã duyệt, chính sách dữ liệu và hoàn tiền |
| Đặt thuê | Kết nối ví, quote có hạn, trạng thái giữ chỗ/ký/chờ xác nhận/lỗi |
| Phiên thuê | Desktop hoặc điểm mở gateway, thời gian, trạng thái, kết thúc và báo lỗi |
| Lịch sử và số dư được rút | Booking, receipt/explorer, khoản được ghi có và thao tác rút |
| Host dashboard | Listing, trạng thái máy, lịch sẵn sàng, booking, doanh thu |
| Admin dashboard | Duyệt máy, sự cố, tranh chấp, log quyết định |

Tình trạng DRAFT của máy không hiển thị cho khách. Các gói gaming/GPU chưa làm chỉ nằm trong roadmap, không có nút thuê giả.

## 5. Giá và thời hạn đề xuất

| Tham số | Giá trị demo |
| --- | --- |
| Giá gói | 0.01 AVAX Fuji |
| Thời gian sử dụng | 15 phút từ startedAt trong block kích hoạt; chỉ cấp truy cập sau xác nhận |
| Hạn quote và giữ chỗ | Tối đa 10 phút |
| Kích hoạt sau thanh toán | Tối đa 5 phút sau hạn funding của quote |
| Phí nền tảng | 10% phần gross trả host |
| Khiếu nại | Trước endAt + 10 phút, kể cả trong phiên |
| Phân xử | Trong 24 giờ từ lúc mở tranh chấp |

Giá trị chain là số nguyên giây/wei; giờ UI theo Asia/Saigon, DB UTC. Điều chỉnh phải nhất quán các tài liệu và ghi quyết định. Thời hạn demo ngắn hơn chỉ được dùng cấu hình test/local riêng có nhãn, không bỏ kiểm tra.

Thời gian chờ xác nhận/cấp truy cập sau startedAt nằm trong gói và phải được đo, công bố. Nếu không cấp được truy cập, chuyển incident/dispute; không âm thầm tính lại startedAt từ client.

## 6. Quy tắc giao dịch và trải nghiệm

- Chưa có receipt hợp lệ: không báo đã thanh toán và không mở desktop.
- Renter được hủy khi hợp đồng còn Funded; giao dịch cancel/activate cạnh tranh được xử lý theo trạng thái chain thực tế.
- Kích hoạt là bằng chứng operator báo đã sẵn sàng, không phải bằng chứng khách đã dùng thành công.
- Mất mạng sau kích hoạt: khách có thể reconnect trong thời gian còn lại hoặc mở tranh chấp; chưa tự tính hoàn theo giây.
- Không tự gia hạn, trừ thêm tiền hoặc đổi giá trong booking.
- Kết thúc sớm và xác nhận thanh toán là hành động từ bỏ quyền khiếu nại tiền của booking đó; UI phải nói rõ trước khi ký.
- Host rút listing chỉ chặn phiên mới; không tự ý cắt phiên đang chạy.
- Host nhận tiền khi được ghi có sau tất toán và thực hiện withdraw; chữ “đã trả” không thay cho giao dịch thực tế.

## 7. Dữ liệu và giới hạn

Dữ liệu trên guest tạm thời; cung cấp cảnh báo và cách tải file trước khi hết phiên. Không hứa lưu dữ liệu sau reset hoặc bảo vệ bí mật khỏi chủ máy. Không tự ghi màn hình khách; dùng dữ liệu demo không nhạy cảm.

## 8. Ngoài MVP

Marketplace host vô danh tự duyệt, nhiều khách/một máy, GPU passthrough/chia GPU, game phổ quát, AI inference API, lưu ổ đĩa lâu dài, lịch tương lai, thanh toán VND/mainnet, token riêng, NFT, ứng dụng host đa nền tảng hoàn chỉnh và tự phát triển giao thức streaming.

## 9. Điều kiện nghiệm thu

- Một host và một khách khác nhau, một desktop thật hoạt động qua hai mạng.
- Đặt trùng bị chặn ở server/database và occupancy của contract; không chỉ disable nút.
- Có giao dịch Fuji thật xác minh được: funding và ít nhất một nhánh kết thúc/withdraw.
- Cấp quyền đúng người; kết thúc chặn phiên đang mở và link cũ.
- Tải lại trang không mất trạng thái và không trả tiền/cấp phiên lặp.
- Nhánh chưa kích hoạt được hoàn tiền; nhánh tranh chấp khóa payout và có lối thoát quá hạn.
- Máy chỉ sẵn sàng lại sau đối soát tiền, thu hồi quyền và reset được kiểm tra.
- Các kiểm tra trọng yếu trong TEST_PLAN qua hoặc ghi rõ phần chưa đạt; không ghi “MVP hoàn chỉnh” khi còn mock remote hay mock payment.

## 10. Demo

Host đăng máy → admin duyệt → khách đặt gói → ký quỹ Fuji → operator kích hoạt → khách gõ/chạy chương trình trên desktop thật → khách kết thúc và xác nhận → rút khoản host/phí → mở explorer.

Demo lỗi riêng dùng booking khác chưa kích hoạt để hoàn tiền. Video không cần chờ 15 phút: dùng đường kết thúc sớm có xác nhận, cắt dựng có nhãn.
