# Máy thật và quyền truy cập

DRAFT. Chưa kiểm tra trên thiết bị thật. Đây là mốc rủi ro cao nhất, phải làm trước khi coi gateway là lựa chọn cuối.

## 1. Phạm vi

Một máy vật lý của host được chỉ định, một guest desktop Linux chuyên để thuê, một khách đồng thời. Có thể dùng guest VM đã được người dùng cho phép cài; không tự thay OS hoặc chọn hypervisor khi chưa khảo sát máy.

Nếu thiết bị không chạy guest đủ tốt, đề xuất dùng máy chuyên dụng sạch. Không cho người lạ điều khiển desktop cá nhân để vượt mốc cho nhanh.

Không cam kết GPU passthrough, chơi game hoặc render acceleration ở MVP. Chạy desktop trên VM không mặc nhiên có GPU thật.

## 2. Hai trải nghiệm cần phân biệt

- Spike kỹ thuật: công cụ remote hiện có có thể dùng để thử mạng và độ trễ.
- Sản phẩm demo hoàn chỉnh: chỉ renter đã trả tiền mới được mở phiên; quyền có hạn, được thu hồi, không phát mật khẩu tĩnh.

Một link remote chia sẻ bằng tay có thể chứng minh máy truy cập được, nhưng chưa đạt tích hợp marketplace.

## 3. Adapter cần có

| Khả năng | Hành vi tối thiểu |
| --- | --- |
| health(machine) | Trạng thái tunnel/guest/desktop đủ mới, không lấy từ client khách |
| prepare(booking) | Chuẩn bị môi trường sạch, ngăn truy cập trước khi trả tiền |
| grant(booking, renter, expiresAt) | Credential ngắn hạn, đúng người/booking, một phiên |
| inspect(booking) | Biết kết nối đang mở và trạng thái revoke, không lộ credential |
| revoke(booking) | Đóng active connections, chặn reconnect và token đã phát |
| reset(machine) | Kết thúc tiến trình khách, xóa môi trường phiên theo cơ chế đã kiểm tra |
| verifyReset(machine) | Bằng chứng tối thiểu guest sạch và không còn kết nối khách trước |

grant/revoke/reset phải idempotent. Unknown không được xem là Success. Reset không chỉ đổi một cờ trong DB hoặc xóa một folder biết trước.

## 4. Guacamole là ứng viên

Guacamole có browser client và encrypted/signed JSON authentication do server phát. Nếu dùng, triển khai theo tài liệu chính thức, không tự sáng tạo thuật toán crypto hoặc lưu credential dưới NEXT_PUBLIC.

Cần khảo sát API/extension phù hợp và thử thực tế việc chấm dứt session. Không giả định JSON expiry hoặc logout UI cắt kết nối desktop đang mở. Nếu API công khai không đủ, dùng cơ chế đóng session/đường kết nối được hỗ trợ và kiểm thử; không dựa API nội bộ chưa được đánh giá mà gọi production-ready.

Gateway giữ bí mật kết nối guest; browser chỉ nhận credential quyền hạn ngắn theo phương thức đã kiểm tra, tránh đặt token trong URL/log/referrer. Tắt public sharing không có kiểm soát.

Nếu chưa đạt trong spike, ghi kết quả và xin người dùng chọn adapter/UX khác hoặc thu hẹp demo; không âm thầm gửi password remote cho khách.

## 5. Host connector tối thiểu

Không viết ứng dụng host đa nền tảng hoàn chỉnh ở bản thi. Guest/network được provision trước trên thiết bị do người dùng chỉ định; connector chỉ báo health, chạy tập lệnh cố định prepare/revoke/reset và xác nhận trạng thái.

Enrollment do admin thực hiện; identity/secret riêng cho từng máy, có thể thu hồi. Heartbeat chống replay bằng nonce/timestamp/counter phù hợp và TLS; không dùng machineId tự khai làm bằng chứng.

Không có endpoint nhận chuỗi shell tùy ý. Secret connector không có quyền quản trị escrow. Connector bị giả mạo vẫn là risk: host kiểm soát thiết bị nên số liệu do host báo không phải bằng chứng độc lập.

## 6. Đường mạng và chống vượt gateway

Máy tại nhà có thể qua NAT/CGNAT. Thiết kế ưu tiên kết nối riêng outbound tới hạ tầng gateway, xác thực hai đầu và giới hạn route tới guest cần dùng; chọn tunnel sau khảo sát.

- Không tự mở RDP/VNC/SSH public hoặc tắt firewall.
- Khách không nhận route vào LAN host.
- Không có đường đăng nhập desktop trực tiếp bằng credential tĩnh để bỏ qua gateway.
- Cấu hình gateway không cho khách sửa hostname/port nhằm truy cập dịch vụ khác.
- Nếu relay được dùng, đo băng thông và chi phí; không hứa mọi phiên đều P2P.

## 7. Thời gian và quyền

endAt từ chain là hạn quyền tối đa. Gateway/watchdog phải ngắt theo hạn ngay cả khi browser bị đóng, worker đối soát chain mất RPC hoặc không có giao dịch settle.

Chỉ mới cấp quyền khi chain confirmed Active, chưa hết endAt, không dispute/terminal, đúng renter và gateway ready. Giới hạn một kết nối; xử lý mở nhiều tab rõ ràng và không tạo nhiều môi trường.

Worker nghe event accept/dispute/terminal để ngắt sớm. Đặt mục tiêu thử nghiệm revoke <= 10 giây trong điều kiện demo; ghi thời gian đo thực tế, không cam kết SLA khi chưa đo.

Nếu control plane lỗi và không thể chứng minh đã revoke, giữ máy unavailable. Chỉ khôi phục máy cho thuê sau reset và đối soát booking.

## 8. Dữ liệu và reset

Guest không có email/token/API key cá nhân. Người thuê dùng dữ liệu công khai và tải file qua cách export có quyền rõ ràng; transfer/clipboard giới hạn theo cấu hình được duyệt.

Giữ dữ liệu trong phiên; cảnh báo trước hết giờ. Sau end/dispute không hứa tải lại file, vì quyền có thể đã bị thu hồi. Chưa có persistent volume cho khách.

Guest VM snapshot/ephemeral disk có thể hỗ trợ reset nhưng phải kiểm tra không còn file, process, credential và connection cũ. Không hứa xóa an toàn khỏi backup/thiết bị vật lý của chủ máy.

## 9. Phiếu spike M0

| Bằng chứng | Hiện trạng |
| --- | --- |
| Host hardware/OS/guest cụ thể | Chưa xác định |
| Truy cập từ hai mạng khác nhau | Chưa thử |
| Desktop gõ/chạy project thật | Chưa thử |
| Đo chuẩn bị, độ trễ, reconnect | Chưa đo |
| Đóng phiên đang mở khi revoke | Chưa thử |
| Link/token cũ không reconnect | Chưa thử |
| Watchdog hết giờ khi worker/web dừng | Chưa thử |
| Reset và isolation của phiên sau | Chưa thử |
| Không có route tới LAN/dữ liệu host | Chưa thử |
| Gateway/relay cost và giấy phép thành phần | Chưa xác định |

Lưu bằng chứng đã lọc secret tại docs/evidence/ sau khi được triển khai. Chỉ ghi PASS sau khi thực hiện, nếu không có máy thì ghi BLOCKED với điều kiện cần, không dựng kết quả.
