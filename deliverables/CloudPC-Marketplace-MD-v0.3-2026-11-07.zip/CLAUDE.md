# Điểm vào cho Claude Code — Cloud PC Marketplace

Đọc và áp dụng [AGENTS.md](AGENTS.md), sau đó đọc [README](README.md), [phiếu duyệt](docs/APPROVAL.md), [MVP](docs/MVP.md), [tiến độ](docs/PROGRESS.md).

**Hiện trạng: chỉ có tài liệu DRAFT chờ chủ dự án duyệt.** Chưa bắt đầu viết ứng dụng hay tạo tài nguyên bên ngoài chỉ vì nhận được bộ tài liệu.

Đọc thêm [thiết kế mới 0.2](docs/PLATFORM_DESIGN_V02.md), [chính sách](docs/MARKETPLACE_POLICIES_DRAFT.md) và [workspace](docs/CLOUD_WORKSPACES.md). MVP/kiến trúc/contract 0.1 chưa đồng bộ đủ yêu cầu mới; không triển khai theo prompt cũ trước khi duyệt lại phạm vi.

Người dùng muốn point blockchain giống trải nghiệm MIU: đọc [POINTS_AND_PAYMENTS](docs/POINTS_AND_PAYMENTS.md) và [POLICY_REFERENCE_REVIEW](docs/POLICY_REFERENCE_REVIEW.md), bổ sung 0.3. Không tự triển khai token/x402 hoặc dùng contract native AVAX cũ; chờ chốt mô hình và đồng bộ đặc tả.

Quy ước chung nằm duy nhất trong AGENTS.md. Không tạo một bộ quy tắc Claude khác với Codex. Chỉ một agent sửa checkout tại một thời điểm; xem [quy trình bàn giao](docs/AGENT_WORKFLOW.md).

Nếu người dùng duyệt triển khai trong chat, ghi nhận đúng phạm vi vào APPROVAL/PROGRESS rồi làm mốc được duyệt theo [hướng dẫn](docs/DEVELOPMENT_GUIDE.md). Không tiếp tục prompt UniAct từ lịch sử.
