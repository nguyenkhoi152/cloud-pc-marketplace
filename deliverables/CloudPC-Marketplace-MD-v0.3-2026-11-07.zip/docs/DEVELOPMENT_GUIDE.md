# Lộ trình từ tài liệu đến bản thi

DRAFT, ngày 07/11/2026. [APPROVAL](APPROVAL.md) quyết định mốc được phép. Chưa có ứng dụng và chưa có lệnh npm của dự án.

Lộ trình này là bản đầu. Đọc [thiết kế 0.2](PLATFORM_DESIGN_V02.md) và đồng bộ phạm vi/lịch nếu đưa workspace/policy/bond/AI vào; không coi ngày mục tiêu hay prompt cũ là quyền tự triển khai.

## 1. Chuẩn bị trong VS Code

Mở đúng thư mục UNIHACK đang chứa README, AGENTS, CLAUDE và docs. Đọc phiếu duyệt; không tiếp tục prompt UniAct trong chat cũ.

Chọn một agent viết, agent còn lại review chỉ đọc theo [AGENT_WORKFLOW](AGENT_WORKFLOW.md). Không cần dùng hai agent cùng sửa, không cần cài thêm công cụ đồng bộ chat.

Sau khi được phép M0, kiểm tra node/npm/git trong terminal VS Code và ghi phiên bản. Trên PowerShell có thể cần npm.cmd thay npm.ps1; không tự hạ execution policy toàn máy. Chọn Node LTS mà dependency thật hỗ trợ; khóa phiên bản khi scaffold.

## 2. M0 — chứng minh remote và chốt kiến trúc

Đầu vào: thiết bị được chủ dự án chỉ định, phạm vi cài đặt cho phép, hai mạng và ngân sách hạ tầng nếu cần.

Thực hiện khảo sát phần cứng/OS/virtualization, đề xuất guest an toàn, thử desktop từ xa, chuẩn bị/grant/revoke/reset. Dùng công cụ hiện có để spike, sau đó chứng minh adapter có thể tích hợp quyền theo booking. Không tự format máy hay mở public port.

Đầu ra: báo cáo R01–R07 trong TEST_PLAN, giải pháp đã chọn, chi phí dự kiến đo được/phần chưa đo và rủi ro. Nếu không có thiết bị hoặc không revoke được, ghi BLOCKED phần này; tiếp tục review tài liệu hoặc việc độc lập đã được duyệt, không gọi full MVP.

## 3. M1 — scaffold và dữ liệu

Đầu vào: MVP được duyệt, M0 cho thấy hướng khả thi, dependency được đối chiếu chính thức.

Tạo web/, contracts/, worker/ theo nhu cầu; migrations, RLS, cấu hình mẫu và gitignore. Chỉ tạo folder khi có nội dung.

Tạo các scripts thực tế cho dev/build/typecheck/lint/test tương ứng module. Ghi chính xác lệnh và thư mục chạy vào README trước kiểm tra. Không giả định Next có next lint hoặc Hardhat có plugin chưa cài.

Làm auth/wallet proof, host/admin, listing, atomic reservation và quote snapshot. UI mẫu phải ghi nhãn; chưa có chain thì không cho mở access thật.

Đầu ra: web local build được, phân quyền và đặt trùng được kiểm tra, docs/PROGRESS cập nhật. Chưa bật deployment công khai chỉ vì local build qua.

## 4. M2 — contract local

Triển khai đúng CONTRACT_SPEC; EIP-712 quote, occupancy, deadlines, pull payment, role/config. Viết và chạy kiểm thử local trước Fuji, gồm cancel/activate race, dispute cutoff, conservation và withdraw lỗi.

Chuẩn bị deploy/export ABI và deployment record; script lấy secret từ cấu hình riêng, không in key.

Đầu ra: tests local có bằng chứng, ABI tích hợp, README có lệnh thực tế. Chưa tạo token riêng.

## 5. M3 — nối gateway và worker

Nối access adapter đã spike; outbox/reconciliation và watchdog. Có nhánh fail closed, revoke active connections/reconnect và reset.

Chạy E2E local: receipt xác minh → preflight → activate → access → end/dispute → revoke/reset. Nếu UI đang demo, không trộn fake receipt với production mode.

Đầu ra: không cấp quyền khi chưa trả tiền, crash/retry không gây double actions, máy không bị giải phóng sớm.

## 6. M4 — Fuji và deploy

Chỉ triển khai đúng network đã được cho phép. Fuji C-Chain: chain ID 43113, RPC https://api.avax-test.network/ext/bc/C/rpc; kiểm tra lại endpoint trước chạy. Dùng ví test riêng và test AVAX.

Các bước:

1. Deploy contract theo script đã tạo và được kiểm tra local.
2. Lưu chain/address/tx/ABI/compiler/config công khai, không lưu secret.
3. Cấp role đúng ví; xác minh không để vai trò mặc định sai từ local.
4. Cấu hình server/worker/gateway qua secret store; web công khai chỉ chứa public config.
5. Deploy web và dịch vụ kết nối dài riêng; khai báo auth redirect, origin và HTTPS.
6. Chạy bằng renter/host thật trong demo và xác minh receipt/explorer.

Không tự mua domain, chọn gói trả phí hoặc đưa desktop ra Internet khi chưa có ngân sách/phạm vi hạ tầng. Nếu chưa có quyền, chuẩn bị toàn bộ cấu hình mẫu và chỉ báo bước cụ thể còn thiếu.

## 7. M5 — review, tài liệu và nộp

Agent thứ hai review chỉ đọc sau khi writer dừng, ưu tiên tiền/quyền/double booking/remote revoke. Writer sửa lỗi có bằng chứng và chạy kiểm tra liên quan.

Chạy kịch bản SUBMISSION; hoàn thiện README cách chạy thật, giới hạn, deployment và URL. Quay video/slide, kiểm tra link và chủ dự án thực hiện Submit theo quyền cho phép.

Không coi trạng thái private preview hay bản build local là site giám khảo đã truy cập được.

## 8. Lịch mục tiêu theo giờ Việt Nam

| Ngày | Mốc |
| --- | --- |
| 07–08/11/2026 | Duyệt tài liệu; M0 máy thật và adapter |
| 09–11/11 | M1 web/dữ liệu/phân quyền/đặt thuê |
| 12–14/11 | M2 contract và kiểm thử local; M3 tích hợp sau khi đạt gate |
| 15–17/11 | M3/M4 E2E, Fuji và bản truy cập được |
| 18–19/11 | M5 review, lỗi, README và kịch bản quay |
| 20/11 | Video, slide, thử link, nộp sớm nếu sẵn sàng |
| 21/11 | Dự phòng, xác nhận Submit trước 23:59 Việt Nam |

Đây là lịch đề xuất, không bảo đảm tiến độ khi duyệt/máy/hạ tầng chưa có. Nếu M0 kéo dài, giảm tính năng mở rộng trước; không bỏ kiểm tra tiền, quyền hoặc dựng mock để nói đã đạt.

## 9. Điều kiện trước kinh doanh thật

MVP hackathon không phải bản sẵn sàng nhận tiền thật. Cần kiểm chứng khách/host, định giá theo chi phí, audit hợp đồng, bảo vệ dữ liệu, license, điều khoản và quy trình vận hành phù hợp. Gaming, GPU và lưu trữ dài hạn là mốc riêng có nghiệm thu.
