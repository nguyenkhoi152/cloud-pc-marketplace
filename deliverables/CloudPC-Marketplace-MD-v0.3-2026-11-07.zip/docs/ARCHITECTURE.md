# Kiến trúc đề xuất

DRAFT, chờ duyệt. Đây là thiết kế cần kiểm chứng, không phải hệ thống đã triển khai.

Yêu cầu [thiết kế 0.2](PLATFORM_DESIGN_V02.md) mới hơn tài liệu này: cần bổ sung workspace/control-storage, policy và commitment trước triển khai phần liên quan. Guacamole dưới đây chỉ là ứng viên 0.1, chưa được chọn.

## 1. Các thành phần

| Thành phần | Trách nhiệm | Không đảm nhiệm |
| --- | --- | --- |
| Web Next.js/TypeScript | UI, API nghiệp vụ, auth, liên kết ví, quote | Giữ WebSocket desktop hoặc timer dài trong request |
| Supabase Auth/PostgreSQL | Tài khoản, RLS, listing, booking, outbox, audit | Tự xác minh kết quả giao dịch do client báo |
| RentalEscrow trên Fuji | Giữ tiền, hạn, trạng thái tiền, chia tiền và withdraw | Kiểm tra desktop, mạng, danh tính hay chất lượng |
| Worker bền vững | Theo dõi receipt/events, hết hạn, gateway cleanup, retry, đối soát | Tin client clock hoặc chỉ dựa callback của trình duyệt |
| Gateway Guacamole (ứng viên) | Truy cập desktop browser, kết nối theo quyền phiên | Tự giải quyết toàn bộ auth marketplace/hoàn tiền |
| Host connector tối thiểu | Báo trạng thái, preflight, điều khiển môi trường thuê theo lệnh giới hạn | Cho API chạy lệnh shell tùy ý/root |
| Guest desktop chuyên dụng | Môi trường khách, ứng dụng học lập trình | Chứa dữ liệu/tài khoản cá nhân của host |

## 2. Công nghệ tham chiếu

- Next.js App Router, TypeScript, Tailwind; viem/wagmi khi tương thích phiên bản.
- Supabase Auth + PostgreSQL + migrations và RLS. Quy tắc tiền/quyền vẫn kiểm tra ở server; service role không đưa vào browser.
- Solidity, OpenZeppelin, Hardhat 3; một hợp đồng không upgrade cho MVP, thanh toán native AVAX Fuji.
- Node LTS được Hardhat/Next hỗ trợ; Node 24 LTS là lựa chọn tham chiếu. Kiểm tra lại trước scaffold; không suy đoán môi trường hiện tại.
- Worker Node/TypeScript chạy thường trực riêng; gateway và dịch vụ desktop chạy trên hạ tầng có kết nối dài. Web có thể deploy Vercel nếu phù hợp; không đặt worker/guacd vào Vercel Function.
- Guacamole là ứng viên đã có tài liệu encrypted JSON authentication. Chưa mặc định expiry của JSON sẽ đóng kết nối đang mở; M0 phải chứng minh khả năng ngắt.
- Máy host có thể giữ hệ điều hành hiện có nếu chạy được guest Linux phù hợp. Không tự đổi OS, cài hypervisor hay bật quyền đặc biệt trước khi chủ dự án chỉ định thiết bị.

Phiên bản chính xác chưa pin vì chưa được code. Khi scaffold phải lưu package manager/version, lockfile, compiler và phiên bản gateway thực tế. Không tạo package.json chỉ để làm tài liệu trông như đã chạy.

## 3. Luồng tổng thể

~~~mermaid
flowchart LR
    R[Khách và ví] --> W[Web và API]
    H[Chủ máy] --> W
    W --> DB[(Auth và PostgreSQL)]
    R --> C[RentalEscrow Fuji]
    W --> C
    K[Worker] --> C
    K --> DB
    W --> K
    R --> G[Gateway desktop]
    K --> G
    G --> T[Kết nối riêng đến guest]
    T --> D[Desktop thuê trên máy host]
    X[Host connector] --> K
    X --> D
~~~

Sơ đồ biểu diễn trách nhiệm, không hàm ý network route đã được cấu hình hoặc các endpoint đều được công khai.

## 4. Trình tự mở một phiên

1. API kiểm tra user, wallet proof, host/machine approved, giờ sẵn sàng và heartbeat.
2. Database khóa máy, tạo booking và quote có hạn trong một transaction; worker đối soát occupancy chain.
3. Server ký quote EIP-712; khách gửi fund trên contract. Quote không chứa IP, credential hay thông tin cá nhân.
4. Worker xác minh receipt/event và contract state, cập nhật Funded một lần.
5. Connector/gateway preflight và chuẩn bị môi trường, chưa cấp quyền cho khách.
6. Operator gửi activate; chờ receipt và state Active phù hợp.
7. API cấp quyền gateway đúng renter/booking; đồng bộ endAt từ chain.
8. Khi hết phiên, kết thúc, dispute hoặc hủy: worker yêu cầu revoke, đóng kết nối đang mở, vô hiệu reconnect và reset.
9. Tiền đi theo CONTRACT_SPEC; quyền truy cập và trạng thái tiền là hai state machine riêng.

Nếu bước 6 thành công nhưng bước 7 lỗi, không giả vờ chưa kích hoạt: chuyển incident, chỉ dẫn khách mở tranh chấp, ghi rõ sự cố cho phân xử.

## 5. Đồng bộ và tính bền vững

- Ghi outbox cùng transaction nghiệp vụ; worker xử lý job có idempotency key, retry và backoff.
- Chain là nguồn chuẩn về tiền; DB là nguồn chuẩn về danh tính, reservation và nhu cầu cấp quyền. Gateway/connector cung cấp trạng thái truy cập thực tế trong giới hạn tin cậy.
- Cursor event lưu bền vững theo chain/contract/block; quét chồng đoạn và chống trùng bằng tx hash + log index.
- Sau crash hoặc tải lại: truy vấn contract state, gateway sessions và DB, khôi phục job thiếu. Không gửi giao dịch mới chỉ vì browser mất trạng thái.
- Receipt cần số xác nhận phù hợp network được cấu hình và ghi lại; nếu reorg/pending/drop không chắc chắn, khóa quyền và đối soát. Không coi một con số confirmation là bảo đảm tuyệt đối.
- Khi RPC/gateway không phản hồi, fail closed: không cấp phiên mới, không giải phóng máy chưa biết trạng thái.
- Thời hạn contract không tự thực thi: worker hoặc người dùng phải gửi giao dịch; UI có nút gọi lối thoát hợp lệ khi worker hỏng.

## 6. Cấu trúc repository dự kiến

~~~text
README.md
AGENTS.md
CLAUDE.md
docs/
web/                  # UI, API, auth; tạo sau duyệt
contracts/            # Solidity, tests, scripts, deployment records
supabase/migrations/  # Schema, RLS, transactions
worker/               # Reconciliation, outbox, gateway control
gateway/              # Cấu hình mẫu; không chứa host credentials
~~~

Đây là cây đề xuất. Không tạo các folder rỗng chỉ để giống repo tham khảo; tái sử dụng cấu trúc có sẵn nếu thích hợp.

## 7. Triển khai và đường đi bí mật

Web HTTPS; worker/gateway cần server có kết nối dài, auth và health check. Kết nối guest qua đường riêng/tunnel được xác thực; không công khai RDP/VNC/SSH cho khách tự quét.

Khóa deploy, quote signer, operator và arbitrator ở server/secret manager, không trong biến NEXT_PUBLIC. Demo có thể vận hành trên cùng hạ tầng nhưng role và quyền vẫn phân biệt. Hồ sơ deployment chỉ ghi địa chỉ công khai/chain/hash.

## 8. Quyết định còn mở

Phương án guest trên thiết bị thật, private tunnel, cách revoke active session và runtime gateway phải được M0 kiểm chứng. Nếu browser streaming hoặc thu hồi không khả thi, đề xuất adapter khác với bằng chứng và ảnh hưởng UX; không âm thầm hạ xuống gửi mật khẩu remote cho khách.
