# Chuẩn bị bài nộp UniHack

DRAFT. Đối chiếu trang BTC ngày 07/11/2026; kiểm tra lại trước nộp vì BTC có thể cập nhật.

## 1. Yêu cầu đã kiểm tra

- Đề tài tự chọn được phép; sản phẩm phải có phần thật chạy trên Avalanche, có thể dùng Fuji.
- Đội 1–3 sinh viên đại học tại Việt Nam; tình trạng đăng ký đội của chủ dự án chưa được kiểm tra.
- Hạn nộp: 23:59 ngày 21/11/2026, giờ Việt Nam.
- Repo GitHub public; nếu private thêm tài khoản tuantqse90 theo FAQ.
- Link pitch slide Canva hoặc Google Slides; video demo 2–3 phút.
- Đăng nhập trang BTC, vào profile/Submit Project; lưu nháp chưa tính nộp, phải bấm Submit.
- Đảm bảo giám khảo mở được repo/slide/video.

Nguồn: [Trang UniHack và FAQ](https://team1vn.xyz/). Đây là thông tin tham khảo cuộc thi, không phải quyền để agent tự nộp bài hoặc chia sẻ tài nguyên.

## 2. Cách bám tiêu chí chấm

| Tiêu chí | Điểm | Bằng chứng đề xuất |
| --- | --- | --- |
| Technical Implementation | 25 | Desktop thật, thu hồi quyền, atomic booking, tests và worker recovery |
| Avalanche Integration | 25 | Escrow Fuji, refund/split/withdraw, địa chỉ và receipt kiểm chứng |
| Creativity & Innovation | 15 | Marketplace có xét duyệt, môi trường học và luồng thuê ngắn; nêu khác biệt có căn cứ |
| Impact & Use Case | 15 | Khách/host thật, phỏng vấn và chi phí đo được |
| Presentation & Pitching | 10 | Vấn đề, demo xuyên suốt và business model rõ |
| UI/UX & Demo | 10 | Trạng thái tiền/quyền rõ, xử lý lỗi và đường thử dễ hiểu |

Không dự báo điểm đạt được. Giới hạn tin cậy và phần chưa làm phải nói thật.

## 3. Kịch bản video 2–3 phút

| Khoảng thời gian | Nội dung |
| --- | --- |
| 0:00–0:20 | Một người cần máy trong thời gian ngắn, một người có máy sẵn sàng |
| 0:20–0:40 | Host đăng máy, admin duyệt; chỉ rõ xét duyệt thủ công |
| 0:40–1:10 | Khách chọn gói, ký fund trên Fuji, mở receipt |
| 1:10–1:45 | Desktop thật: gõ/chạy một chương trình; thấy trạng thái phiên |
| 1:45–2:10 | Khách xác nhận kết thúc; kết nối bị ngắt, số tiền được chia/withdraw |
| 2:10–2:35 | Booking lỗi chưa kích hoạt được hoàn tiền; giải thích dispute ngắn |
| 2:35–2:55 | Thu phí thế nào, giới hạn host/operator và bước phát triển tiếp |

Các bước có thể quay sẵn/cắt dựng rõ ràng; không giả trạng thái thanh toán hoặc thao tác desktop. Dùng kết thúc sớm có xác nhận thay vì giả đã chờ đủ 15 phút.

Không để seed/private key, token gateway, mật khẩu hoặc thông tin khách thật vào video.

## 4. Slide đề xuất

1. Vấn đề và khách hàng đầu tiên.
2. Sản phẩm và hai phía thị trường.
3. Luồng thuê thật.
4. Kiến trúc và vị trí Avalanche.
5. Escrow, hoàn tiền, quyền operator/arbitrator và giới hạn.
6. Demo/bằng chứng đã đo; phân biệt mock.
7. Mô hình thu phí, chi phí và kết quả kiểm chứng thị trường.
8. Roadmap, đội và link thử.

Chưa có khảo sát thì ghi chưa có; không tự tạo số người dùng, đối tác, doanh thu hoặc tuyên bố hợp tác với trường.

## 5. README cuối cần bổ sung sau triển khai

- URL web và hướng dẫn thử với tài khoản/ví test; không công khai admin credentials.
- Stack/version thực tế, cấu trúc repo, script dev/build/test chính xác.
- Tên biến môi trường và placeholder; secret nhập ở cấu hình riêng.
- Migrations, cách tạo host/admin đúng quyền, cấu hình guest/gateway/worker.
- Contract address/chain/deployment tx/ABI và receipt demo có thật.
- Phân biệt UI mẫu, mock và chức năng thật; các giới hạn của bản thi.
- License, nguồn thành phần và ghi nhận tác giả theo giấy phép.

## 6. Trải nghiệm giám khảo

Web mở được qua Internet và HTTPS. Cho đăng ký tài khoản khách hoặc chuẩn bị cơ chế demo có giới hạn, không chia mật khẩu quản trị. Ví phải có AVAX Fuji dùng funding và gas; hướng dẫn faucet nhưng không hứa faucet luôn hoạt động.

Nếu host không online 24/7, nói rõ giờ demo và cung cấp video chứng minh luồng thật. Video không thay yêu cầu source/tài liệu trung thực. Không hứa dùng tức thì khi máy đang offline.

Kiểm tra các link ở trạng thái không đăng nhập chủ sở hữu; đảm bảo không có deployment protection ngoài ý muốn. Private repo phải cấp quyền đúng tài khoản BTC.

## 7. Phiếu trước Submit

- [ ] Đã kiểm tra lại deadline và yêu cầu mới nhất.
- [ ] Đủ điều kiện đội và đã đăng ký.
- [ ] Repo và đúng quyền truy cập.
- [ ] Slide mở được.
- [ ] Video 2–3 phút mở được.
- [ ] Web/gateway theo đúng trạng thái công bố.
- [ ] Có địa chỉ/receipt Fuji đã xác minh.
- [ ] README phân biệt thật/mock/chưa làm.
- [ ] Không lộ secret hoặc dữ liệu riêng.
- [ ] Chủ dự án duyệt nội dung công bố.
- [ ] Đã bấm Submit và xác nhận trạng thái nộp.

Tất cả checkbox đang chưa hoàn thành; không tích sẵn để làm đẹp hồ sơ.
