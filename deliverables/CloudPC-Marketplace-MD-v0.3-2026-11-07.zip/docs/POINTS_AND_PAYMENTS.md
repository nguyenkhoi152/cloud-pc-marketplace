# Point, Avalanche và thanh toán — đề xuất 0.3

Ngày: 07/11/2026, Asia/Saigon. **DRAFT CHỜ DUYỆT. Chưa phát hành token, chưa triển khai hợp đồng hoặc thu tiền.**

## 1. Yêu cầu mới

Chủ dự án muốn có point tương tự trải nghiệm MIU và tham khảo Computing Point của EZYCLOUDX. Đây là quyền nghiên cứu/thiết kế point; chưa phải quyết định mainnet, bán token, tỷ giá, quyền chuyển, x402 hoặc cash-out.

Yêu cầu này mới hơn lựa chọn native AVAX-only của D06/bản contract 0.1. Không tiếp tục code thiết kế tiền cũ mà không đồng bộ.

## 2. Giải thích thuật ngữ

| Khái niệm | Nghĩa trong đề xuất |
| --- | --- |
| Point/credit | Đơn vị sản phẩm hiển thị để tính thuê máy/cloud |
| Avalanche C-Chain | Mạng EVM chạy hợp đồng, không phải tên point của dự án |
| Fuji | Mạng test dùng cho bài thi, chain ID 43113 |
| AVAX Fuji | Tài sản thử dùng trả gas; không phải point thuê máy nếu dùng token riêng |
| ERC-20 | Giao diện token có số dư/allowance/chuyển; không tự kèm hạn dùng/refund hay giá trị bảo đảm |
| Địa chỉ 0x… | Cách hiển thị địa chỉ ví/contract EVM; không tự chứng minh đúng token, chain hoặc uy tín |
| x402 | Chuẩn yêu cầu/thực hiện thanh toán qua HTTP, không phải đồng coin hoặc hệ thống escrow có sẵn |

Phải kiểm tra chainId + token contract + escrow contract + decimals + receipt, không chỉ nhìn ký hiệu point hoặc tiền tố 0x.

Nguồn: [Avalanche networks](https://build.avax.network/docs/primary-network), [OpenZeppelin ERC-20](https://docs.openzeppelin.com/contracts/5.x/erc20), [x402](https://docs.x402.org/introduction).

## 3. MIU mẫu thực sự làm gì?

Đã đọc MiuCoin.sol và README trong repo SenpAI: token thử ERC-20, có permit/EIP-3009, owner mint; facilitator dùng chữ ký để gửi giao dịch trả token. Chỉ tham khảo kiến trúc, không coi đây là token mainnet có backing hoặc hệ thống đã được audit.

Nguồn: [MiuCoin.sol](https://github.com/tuantqse90/senpai/blob/main/web/contracts/src/MiuCoin.sol), [SenpAI README](https://github.com/tuantqse90/senpai).

Không tái sử dụng tên MIU, contract address, mint authority hoặc cơ chế cấp token của họ làm thương hiệu/cấu hình dự án. Nếu tái sử dụng code, tuân thủ license và review độc lập.

## 4. Ba mô hình có thể chọn

| Mô hình | Số dư point ở đâu? | Mặt thuận lợi | Điều phải đánh đổi |
| --- | --- | --- | --- |
| A — credit nội bộ | Ledger database | Dễ promo/expiry/refund và che lịch sử khỏi public chain | Người dùng tin hệ thống point của nền tảng; blockchain là lớp khác |
| B — point token thử | ERC-20 trên Fuji, DB chỉ index/cache | Gần trải nghiệm MIU, minh chứng on-chain rõ | Cần gas, quyền mint/transfer, wallet UX và kiểm chứng contract |
| C — kinh doanh/hybrid | Ledger point + dòng tiền và payout riêng có đối soát | Có thể quản lý nghĩa vụ tiền, promo và host | Cần phương án thanh toán/dự trữ/payout/tuân thủ riêng; không suy ra từ test token |

Đề xuất B cho bản thi, nghiên cứu C khi kinh doanh. Không bán faucet token thử cho khách hoặc hứa chuyển số dư test sang tiền thật.

## 5. Token demo đề xuất

Tên làm việc PC Point, ký hiệu PCP, chưa chốt thương hiệu. Deploy một token trên Fuji; ví demo nhận token miễn phí theo allowlist/budget để thử. Không gắn tỷ giá VND, giá niêm yết sàn hoặc hứa tăng giá.

Đề xuất thiết kế credit giới hạn chuyển:

- Mint chỉ từ issuer có quyền và giới hạn chính sách, có event.
- Renter chỉ chi qua escrow được cho phép; escrow hoàn token/chia token theo booking.
- Host và treasury nhận số dư thử; có thể chi trong hệ thống theo điều kiện được duyệt.
- Không P2P giữa tài khoản nếu chọn quy tắc credit đóng; chặn trong contract, không chỉ ẩn nút.
- Không DEX/staking/yield; không tự thêm mainnet.

ERC-20 thông thường cho chuyển token tự do. Muốn hạn chế phải thiết kế và test riêng mọi đường transfer/transferFrom/authorization; không nói đã giống point đóng chỉ vì website không có nút gửi.

Token lưu số nguyên base units, decimals chọn/pin khi triển khai; không dùng float. Không tự lấy giá trị 0.01 AVAX cũ rồi gọi thành 0.01 PCP.

## 6. Luồng thuê dùng point

1. Renter liên kết ví, nhận PCP thử và thấy số dư xác nhận từ chain.
2. Chọn máy; server tạo quote ký, ràng buộc booking, machine, renter, host, token address, amount base units, fee, deadline và policy version.
3. Renter approve đúng allowance cần thiết cho escrow rồi gọi fund booking.
4. Token được escrow pull theo một transaction funding; amount/booking/occupancy ghi nguyên tử. Không nhận token chuyển tay vào contract như booking hợp lệ.
5. Worker xác minh event/state, operator chuẩn bị/kích hoạt theo đặc tả mới được duyệt; mới cấp remote access.
6. Hoàn tất hoặc phân xử: escrow phân chia token/credit theo booking; rút token là một bước riêng nếu dùng pull payment.
7. Không thu point on-chain cho từng giây/frame/phím bấm. Bản đầu dùng gói cố định, telemetry chỉ là bằng chứng vận hành.

Ví dụ minh họa cho một template demo: ví có 1000 PCP; một gói tốn 20 PCP; giữ 20, còn 980 khả dụng. Thành công và phí 10%: host 18, nền tảng 2. Chưa kích hoạt được và hoàn đủ: 20 về renter, không thu phí phiên. Các số này chưa duyệt và không là giá thương mại.

Escrow phải chấp nhận duy nhất token cấu hình, dùng thư viện chuyển an toàn, không tự hỗ trợ fee-on-transfer/rebase token. Không có fallback coi AVAX gửi nhầm là PCP payment; cần quy trình xử lý tài sản chuyển ngoài ý muốn.

## 7. x402 và gas

Đề xuất làm approve + escrow funding trước cho dễ kiểm chứng. Có thể nâng trải nghiệm ký/relayer sau; không bắt buộc x402 để có point trên Avalanche.

Nếu dùng EIP-3009/x402, giao dịch chuyển token phải được gắn nguyên tử với booking. Một facilitator mặc định chỉ chuyển token không tự tạo state Funded, lock máy hoặc policy refund.

Hướng cần khảo sát: escrow nhận authorization qua hàm funding có kiểm tra payee/renter/amount/nonce/deadline/domain/booking; dùng receive-with-authorization khi phù hợp hoặc thiết kế router đã được review. Không thêm wrapper rồi mặc định tương thích mọi facilitator.

Phải kiểm tra replay giữa chain/contract/booking, sai payee, token giả, cấp allowance quá rộng, front-run và receipt phục hồi sau lỗi. Chữ ký tiêu token không phải chữ ký đăng nhập.

Gas vẫn bằng AVAX Fuji. Nếu nền tảng tài trợ gas, relayer dùng AVAX và phải xác thực/giới hạn ngân sách. Tài trợ bước funding không tự tài trợ cancel/dispute/withdraw; không quảng cáo “khách không bao giờ cần AVAX” trước khi kiểm tra toàn bộ luồng và lối thoát khi relayer chết.

## 8. Paid, promo và host earnings khi kinh doanh

Demo chỉ có PCP thử, không được gắn nhãn “đã mua bằng tiền thật”. Còn sản phẩm thương mại cần các ledger tách biệt:

| Ledger | Nguồn | Quy tắc |
| --- | --- | --- |
| Purchased credits | Thanh toán đã xác minh | Gắn payment/refund history, không tự đặt expiry bất lợi |
| Promotional credits | Chương trình do nền tảng tài trợ | Có điều kiện/hạn công bố; không tự cash-out |
| Reserved credits | Khóa cho booking | Không chi trùng; giải phóng theo state |
| Host earnings | Phần dịch vụ đã đối soát | Chờ payout; không đồng nhất với point được tặng |
| Host bond | Tài sản cam kết riêng | Không mint promo để tạo bảo đảm giả |

Một token fungible chuyển tự do sẽ làm khó việc truy nguồn paid/promo/expiry. Nếu cần các quyền khác nhau, chọn ledger lot/token riêng/coupon được review; không chỉ gắn cờ DB rồi coi số dư wallet fungible đã giữ nguyên nguồn gốc.

Promo không tạo tiền. Nếu khách dùng 100 điểm tặng để thuê host, phần host được hưởng phải được tài trợ từ ngân sách thật đã khóa/đối soát, hoặc host đã chấp nhận chương trình cụ thể. Không cho withdraw tiền thật từ faucet/promo không có backing.

Host earnings và bond dùng tài sản nào, tỷ giá nào, settlement lúc nào, ai gánh phí/biến động và ai trả tiền thật vẫn CHƯA CHỐT. Tạo token không tự giải quyết payout.

## 9. Hoàn point khác hoàn tiền

| Tình huống | Đề xuất |
| --- | --- |
| Chưa cấp được phiên | Hoàn khoản PCP đã giữ của booking; gas đã dùng không tự hoàn |
| Sự cố được xác nhận trong phiên | Hoàn theo gói/quy tắc downtime đã duyệt; không tự tin thời gian do host báo |
| Khách tự kết thúc sớm | Hiển thị chính sách gói trước ký; không mặc định tính theo phút khi contract chưa hỗ trợ |
| Hoàn khoản đã mua thương mại | Qua payment/refund ledger riêng, tránh vừa trả tiền vừa giữ point đã hoàn |
| Promo bị refund | Trả đúng loại/quyền/hạn theo chính sách, không biến thành purchased credit hoặc tiền |
| Sự cố do nền tảng | Không tự lấy bond host; nguồn bồi hoàn phải rõ |
| Tài khoản bị hạn chế | Giữ bằng chứng/appeal, không tự tịch thu mọi số dư |

Không tự gia hạn compute trong MVP. Nếu thêm, yêu cầu đồng ý, trần chi, đủ thời gian host và cảnh báo. Storage subscription là dịch vụ riêng, không đồng nghĩa được khóa file ngay khi compute hết point.

## 10. Chính sách privacy có blockchain

Ví, token balance và các giao dịch công khai có thể bị liên kết; người dùng cần biết trước khi chọn ví. Không cam kết xóa on-chain history khi họ yêu cầu xóa tài khoản.

PII, IP, endpoint host, credential, file dự án, lý do dispute có dữ liệu cá nhân và chat AI không đưa lên chain. Dùng booking ID ngẫu nhiên; dữ liệu tối thiểu vẫn có thể liên kết ví.

Support, cloud/auth/AI/relay/payment providers chỉ nhận dữ liệu cần; công bố theo cấu hình thực tế. Không tuyên bố “không bên thứ ba nào tiếp cận” nếu vẫn sử dụng dịch vụ xử lý bên ngoài.

## 11. Các tài liệu/code cần đổi trước triển khai

- CONTRACT_SPEC native AVAX 0.1 cần viết lại thành escrow token, không chỉ đổi nhãn UI.
- Quote, API, DB, ledger và event verifier cần asset address/decimals/base units.
- Chốt restriction, issuer powers, pause có lối thoát, supply policy và quản lý key.
- Nếu chọn promo/purchased ngay, phải đặc tả lot expiry/refund/subsidy trước code.
- Test conservation theo token balance, chống funding/withdraw/refund lặp, sai token, transfer restrictions và allowance.
- Viết lại claim UX: Available/Reserved/Spent/Refunded/Earned/Payout pending và gas.
- Bond không được tự dùng cùng token mint tùy ý mà quảng cáo là bảo đảm giá trị.

## 12. Cần duyệt

PCP chỉ là tên tạm; cần chốt mô hình A/B/C, quyền chuyển, point test hay paid, gói/giá, gas sponsor, có x402 ngay không và cơ chế trả host tương lai. Chưa được bán token, đưa mainnet hoặc công bố điều khoản kinh doanh.
