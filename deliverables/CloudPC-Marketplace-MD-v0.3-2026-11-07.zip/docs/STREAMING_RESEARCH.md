# Nghiên cứu vận hành chợ Cloud PC và kết nối desktop

Ngày: 07/11/2026, Asia/Saigon. DRAFT nghiên cứu bổ sung theo yêu cầu chủ dự án. Chưa được duyệt chọn công nghệ, chưa cài hay đo trên máy thật.

## 1. Kết luận đề xuất

Nếu ưu tiên độ mượt và chấp nhận ứng dụng client: thử Sunshine ở môi trường thuê và Moonlight ở thiết bị khách làm baseline. Parsec native là đối chứng nếu có quyền sử dụng phù hợp.

Nếu bắt buộc dùng ngay trong website: thử Selkies với WebRTC và GPU encoding trên Linux; với Windows đánh giá giải pháp có hỗ trợ Windows/browser như Amazon DCV hoặc giải pháp thương mại có quyền tích hợp được xác nhận.

Không có benchmark của chính dự án để kết luận giải pháp nào nhanh nhất. Guacamole trong D11 và kiến trúc hiện tại chỉ là ứng viên cũ, không phải lựa chọn đã duyệt. Trước khi code, cần cập nhật thiết kế theo kết quả spike, không áp dụng khuyến nghị này như quyết định tự động.

## 2. Người khác vận hành thế nào?

### AirGPU — tham khảo trải nghiệm Cloud PC

AirGPU cho khách tạo máy rồi kết nối bằng Parsec hoặc Moonlight. Đây là bằng chứng một dịch vụ Cloud PC có thể dùng streaming engine có sẵn. Không dùng bằng chứng này để gọi AirGPU là chợ PC cá nhân.

Nguồn: [AirGPU](https://airgpu.com/).

### TensorDock — tham khảo marketplace hạ tầng

TensorDock xét duyệt host, cài phần mềm quản lý dựa trên Libvirt và cho khách triển khai VM trên máy host. Trang onboarding yêu cầu chất lượng nguồn điện/mạng; phần cứng mới phải ở data center. Đây là nguồn cung chuyên nghiệp hơn ý tưởng ai có PC ở nhà cũng đăng được.

Nguồn: [TensorDock host onboarding](https://www.tensordock.com/host.html).

### Vast.ai — tham khảo chất lượng nguồn cung

Vast công bố verification đánh giá sức khỏe, hiệu năng và độ tin cậy của máy; đạt baseline không tự động bảo đảm được verified. Đây là marketplace compute/GPU, không mặc định là thuê desktop tương tác giống sản phẩm đang đề xuất.

Nguồn: [Vast verification](https://docs.vast.ai/host/understanding-verification).

### Bài học áp dụng

Chợ không chỉ có listing và thanh toán: phải có onboarding thiết bị, điều phối, đo chất lượng, phân quyền phiên, xử lý mất mạng, reset và đối soát. Các bước dưới đây là thiết kế đề xuất của dự án, không khẳng định mọi đối thủ có cùng implementation.

## 3. Kiến trúc marketplace cần hai đường riêng

~~~mermaid
flowchart LR
    H[Chủ máy] --> HA[Host Agent]
    HA <-->|Trạng thái và lệnh giới hạn| B[Backend marketplace]
    U[Khách] --> W[Website chọn máy và trả tiền]
    W --> B
    W --> C[Escrow Fuji]
    B --> C
    HA --> D[Guest desktop riêng]
    D <-->|Hình ảnh âm thanh và input| CL[Moonlight hoặc browser client]
    U --> CL
~~~

- Control plane: đăng máy, đặt thuê, xác thực, cấp/revoke, heartbeat, tiền và audit.
- Streaming plane: capture, encode trên host, gửi video/audio, decode trên client và gửi input ngược lại.
- Website hoặc blockchain không xử lý từng frame video hoặc từng phím bấm.
- Host Agent là phần mềm của nền tảng cần xây mỏng để điều phối; không thay thế Sunshine/Parsec/Selkies, không cần tự viết codec.

Streaming ưu tiên đường trực tiếp đủ tốt. Nếu không đi được, dùng relay/network route tương thích giao thức. Relay có thể vẫn cần khi hai máy đều có Internet.

## 4. So sánh ứng viên

| Ứng viên | Môi trường/trải nghiệm | Điểm phù hợp | Điều cần kiểm chứng |
| --- | --- | --- | --- |
| Sunshine + Moonlight | Host và client tương thích, client native là baseline | GPU hardware encoding; dùng desktop và game; tự vận hành | Pair theo booking, route mạng, active-session revoke, guest/GPU, license |
| Parsec native | Remote workstation, phải kiểm tra host OS/feature matrix | Đối chứng nhanh về cảm giác sử dụng; enterprise có API/relay | Hợp đồng thương mại, quyền marketplace/SDK, tự động hóa và thu hồi |
| Selkies | Desktop Linux tới browser | GPU-accelerated browser streaming, WebRTC là tùy chọn | Chọn đúng transport, ICE/TURN, auth/revoke, browser codec và isolation |
| Amazon DCV | Server Windows/Linux và client native/browser | Có quản lý desktop/session cho hướng workstation | License ngoài EC2, quyền cung cấp cho khách, gateway integration và latency |
| Guacamole | Browser gateway RDP/VNC/SSH | Desktop văn phòng, khả năng tích hợp có tài liệu | Không có benchmark nội bộ; chưa chọn làm baseline cho gaming/3D |
| Wolf + Moonlight | Linux/Docker, điều phối app/desktop | Có API pairing/session, hướng orchestration đáng khảo sát sau | GPU/container isolation, lệnh API đặc quyền, revoke và độ phức tạp |

Đây là đánh giá phù hợp do dự án đề xuất, không phải bảng xếp hạng FPS/độ trễ đã đo.

### Sunshine và Moonlight

Sunshine là host streamer, có hardware encoding cho GPU phù hợp của NVIDIA/AMD/Intel; Moonlight là client, có thể truyền cả desktop. Sunshine có web UI quản trị nhưng web UI đó không tự biến Moonlight thành browser player.

Có API quản lý/pair/unpair trong tài liệu Sunshine. Không kết luận unpair chắc chắn cắt active stream trên mọi bản; phải kiểm tra phiên bản pin. API quản trị ở mạng riêng, chỉ connector/backend được phép gọi, không đưa username/password cho renter.

Nguồn: [Sunshine](https://github.com/LizardByte/Sunshine), [API](https://docs.lizardbyte.dev/projects/sunshine/latest/md_docs_2api.html), [Moonlight](https://moonlight-stream.org/).

### Parsec

Parsec mô tả pipeline capture/video và P2P, GPU encoding/decoding; Enterprise có REST API và relay. Tài liệu web client nói hiệu năng/độ ổn định có thể kém native client của chính Parsec. Không suy rộng phát biểu đó thành mọi browser streaming đều không thể GPU-decode.

Unity yêu cầu license phù hợp cho mục đích thương mại. Không coi bản miễn phí hoặc mua Teams mặc nhiên cho phép nhúng/white-label/bán lại trong marketplace; cần xác nhận quyền cụ thể.

Nguồn: [Technical overview](https://support.parsec.app/hc/en-us/articles/32361354307348-Overview), [Web client](https://support.parsec.app/hc/en-us/articles/32381650129300-Use-the-Web-App-browser), [Unity FAQ](https://unity.com/products/parsec).

### Selkies

Tài liệu hiện tại mô tả Linux-native browser streaming, mặc định WebSockets và WebRTC là opt-in. Vì vậy không nên dùng lệnh cài cũ rồi giả định đã có WebRTC. Selkies không tự cung cấp một desktop Windows tương đương.

Nguồn: [Selkies](https://docs.selkies.io/latest/), [Network/firewall](https://docs.selkies.io/latest/firewall).

### Amazon DCV và Wolf

DCV có client browser/native và server Windows/Linux; license trên máy ngoài EC2 phải được xem xét riêng. Không coi miễn phí khi chạy trên máy cá nhân chỉ vì dùng được trên EC2.

Wolf có API điều phối qua UNIX socket; tài liệu cảnh báo API có thể pair client và chạy lệnh. Đây là quyền cao, không expose trực tiếp ra Internet hoặc cho browser khách gọi.

Nguồn: [DCV servers](https://docs.aws.amazon.com/dcv/latest/adminguide/servers.html), [DCV licensing](https://docs.aws.amazon.com/dcv/latest/adminguide/setting-up-license.html), [Wolf API](https://games-on-whales.github.io/wolf/stable/dev/api.html).

## 5. Vì sao chọn phần mềm thôi chưa đủ mượt?

Thời gian từ thao tác đến ảnh hiển thị gồm đường input đi tới host, render/capture, encode, truyền video về, decode và màn hình client. Ping không đo toàn bộ chuỗi.

### Những biến cần đo

- Đường truyền giữa chính khách và host: RTT, jitter, packet loss và thông lượng đủ ổn định.
- Upload khả dụng của host và download của khách; host tải game hoặc khách xem video khác có thể làm thay đổi kết quả.
- GPU encoder có được dùng thật hay fallback CPU; guest VM có GPU tương thích hay không.
- Client giải mã phần cứng được codec đang dùng; laptop yếu/điện thoại vẫn cần đủ khả năng hiển thị stream.
- Độ phân giải, FPS, bitrate, codec, cấu hình chất lượng màu và màn hình.
- Route direct hay relay; nhà mạng và thời điểm trong ngày. Cùng thành phố chưa chắc cùng chất lượng đường đi.

Nguồn cho phân biệt encoding/decoding/network stats: [Parsec stats](https://support.parsec.app/hc/en-us/articles/32381603663636-Stream-Overlay-Stats-and-Logging), [troubleshooting](https://support.parsec.app/hc/en-us/articles/32381352822804-Troubleshooting-Lag-Latency-and-Quality-Issues).

### Cấu hình thử ban đầu đề xuất

1080p/60fps, H.264 khoảng 15 Mbps, cả hai đầu dùng Ethernet nếu có; kiểm tra hardware encode/decode đang hoạt động. Các giá trị này là điểm xuất phát để đo, không phải yêu cầu tối thiểu hay bảo đảm 60fps.

Chỉ tăng 1440p/4K/FPS sau khi baseline ổn. HEVC/AV1 chỉ chọn khi hai đầu hỗ trợ phù hợp và kết quả tốt hơn; codec mới không mặc nhiên ít trễ hơn.

Với code/chữ nhỏ, kiểm tra độ rõ text/chroma; với game ưu tiên frame pacing/input. Không dùng cùng một cấu hình chất lượng để hứa tối ưu mọi tác vụ.

## 6. NAT, relay và tiền băng thông

Browser WebRTC dùng ICE/STUN để tìm đường, TURN khi cần relay. Không bảo đảm kết nối trực tiếp mọi cặp mạng, đặc biệt CGNAT/firewall hạn chế. Selkies có tài liệu thiết lập TURN và lựa chọn transport.

Với Sunshine/Moonlight, dùng route UDP/private network tương thích; không mặc định cắm TURN của WebRTC vào giao thức Moonlight. Có thể khảo sát WireGuard/Tailscale theo tài liệu, nhưng chỉ cấp route cần thiết cho guest của booking, không cho renter vào mạng LAN hoặc mạng riêng của mọi host.

Relay nên chọn theo RTT thực tế từ hai đầu, ưu tiên vị trí phù hợp khách Việt. Server Mỹ cho khách/host ở Việt Nam có thể làm đường đi vòng xa; không mua server theo giả định địa lý mà chưa đo.

Nếu stream trung bình 20 Mbps, một giờ video một chiều khoảng 20 × 3600 / 8 = 9000 MB, tức 9 GB thập phân, chưa tính overhead/audio/input. Relay phải xử lý cả nhận và gửi; cách tính tiền tùy nhà cung cấp. Chi phí này có thể ảnh hưởng lớn phần phí marketplace.

Nguồn: [WebRTC TURN](https://webrtc.org/getting-started/turn-server), [Selkies networking](https://docs.selkies.io/latest/firewall), [Moonlight networking overview](https://moonlight-stream.org/).

## 7. Cách vận hành được đề xuất cho chợ

1. Host cài agent; đăng ký thiết bị bằng enrollment credential riêng.
2. Kiểm tra cấu hình thật, benchmark tác vụ, encoder, mạng, khả dụng và môi trường thuê sạch.
3. Chỉ listing được duyệt mới nhận thuê; khả dụng tính theo heartbeat và lock.
4. Khách chọn máy theo ứng dụng/cấu hình và kết quả kiểm tra kết nối, không chỉ theo GPU/giá.
5. Sau booking/funding hợp lệ, agent chuẩn bị guest và cấp quyền client theo phiên.
6. Hệ thống theo dõi sức khỏe và chất lượng phiên; không ghi nội dung màn hình/bàn phím khách.
7. Hết giờ hoặc kết thúc: đóng active stream, thu hồi pair/token/route, chặn reconnect, reset guest.
8. Tất toán/hoàn tiền theo contract; máy chỉ nhận phiên sau khi cleanup được xác minh.

MVP không nhất thiết xây thuật toán matching tối ưu; có thể lọc máy thủ công theo benchmark rồi thêm scoring khi có dữ liệu.

## 8. Isolation: streamer không tạo PC riêng

Sunshine và Parsec truyền một desktop được cấu hình; không mặc nhiên tạo VM sạch cho khách. Virtual display cũng không tự cách ly người dùng/file/process.

Đề xuất bắt đầu với host có máy chuyên để thuê hoặc guest riêng được cấp tài nguyên phù hợp. Nếu guest cần 3D/GPU thật, phải kiểm tra khả năng gán GPU trên phần cứng/OS cụ thể; không giả định mọi PC Windows có thể cài VM là xong.

Container như trong Wolf/Selkies không đồng nghĩa VM chống host độc hại; một số cách cấp GPU/input có quyền cao. Host quản trị máy vật lý vẫn là bên phải tin cậy đối với dữ liệu khách. Không nhận secret hoặc dữ liệu nhạy cảm để demo.

## 9. License cần kiểm tra theo bản dùng

- Sunshine và Moonlight công bố GPL-3.0; lưu notice/license và xem nghĩa vụ khi sửa/phân phối. Không suy ra toàn bộ website tự động phải GPL chỉ vì chạy dịch vụ bên cạnh.
- Parsec cần license thương mại phù hợp, xác nhận quyền SDK/hosting/resale riêng.
- Selkies hiện công bố MPL-2.0 cho dự án và có dependency mang license khác. Đối chiếu đúng tag/image được dùng, không dựa bài viết cũ nói Apache-2.0.
- DCV ngoài EC2 có cơ chế license riêng. License streamer không thay quyền cho thuê Windows/game/phần mềm.

Nguồn: [Sunshine repository](https://github.com/LizardByte/Sunshine), [Moonlight](https://moonlight-stream.org/), [Selkies licensing](https://docs.selkies.io/latest/licensing), [DCV licensing](https://docs.aws.amazon.com/dcv/latest/adminguide/setting-up-license.html), [Unity FAQ](https://unity.com/products/parsec).

Đây là việc cần đối chiếu license, không phải kết luận pháp lý về mô hình thương mại.

## 10. Thử nghiệm để chọn giải pháp

Chưa được phép cài phần mềm hoặc thay máy từ yêu cầu nghiên cứu này. Khi chủ dự án cho thử trên thiết bị cụ thể:

- Windows: Sunshine/Moonlight so với Parsec native nếu được cấp quyền dùng, cùng máy/đường mạng/tác vụ/cấu hình.
- Linux: Sunshine/Moonlight so với Selkies browser WebRTC, xác minh mỗi bên có GPU tương đương.
- DCV chỉ thêm nếu cần browser Windows và đã xác nhận khả năng license/tích hợp.
- Mỗi cấu hình thử thao tác chữ/scroll và chuyển động liên tục, ghi FPS/drop, RTT p50/p95, jitter/loss, encode/decode, direct/relay, tài nguyên và băng thông.
- Kiểm tra revoke khi còn stream, reconnect bằng link/pair cũ, hết giờ khi backend hỏng và reset phiên sau.
- Không gọi p95 RTT là input-to-photon; đo đầu cuối bằng phương pháp riêng nếu cần so sánh cảm giác input chính xác.
- Không gộp kết quả khác OS/GPU/network rồi xếp hạng phần mềm.

Kết quả cần lưu: giải pháp đủ mượt trên máy thật, điều kiện mạng đạt, cách cấp/thu hồi, chi phí và giới hạn. Chưa có kết quả nào trong báo cáo này.

## 11. Ảnh hưởng đến bộ tài liệu cũ

Đề xuất xem lại D03 (Linux-only nếu khách hàng muốn Windows) và D11 (không mặc định Guacamole cho ưu tiên gaming/3D). Các mục đó vẫn CHỜ DUYỆT; MVP/CONTRACT chưa bị thay bằng thiết kế streaming mới.

Khuyến nghị thực hiện trước: spike Sunshine/Moonlight làm chuẩn trải nghiệm, rồi quyết định có cần browser ngay từ bản đầu. Có website marketplace không bắt buộc video phải chạy trong browser.
