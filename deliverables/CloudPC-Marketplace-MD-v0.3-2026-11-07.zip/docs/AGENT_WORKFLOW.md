# Claude Code và Codex làm chung

DRAFT. Nguồn quy ước là AGENTS ở gốc; quyết định là APPROVAL; trạng thái tiếp tục là PROGRESS.

## 1. Cách dùng bộ tài liệu

Giữ README.md, AGENTS.md và CLAUDE.md ở gốc repository; các tài liệu còn lại trong docs/. Mở chính folder này trong VS Code. Nếu tải ZIP, giải nén vào một thư mục riêng rồi review trước khi chép đè vào checkout khác.

Chat không tự đồng bộ mọi điều agent khác đã nói. Mỗi phiên phải đọc file hiện tại và kiểm tra code. Không dùng trí nhớ chat làm nguồn sự thật duy nhất.

## 2. Vai trò

Chọn Claude viết/Codex review hoặc ngược lại. Không mặc định agent nào luôn có quyền sửa. Trong cùng checkout, chờ writer dừng rồi mới chuyển writer; review chỉ đọc.

Không tự spawn agent hoặc tạo chat mới. Nếu chủ dự án cho phép dùng worktree riêng, vẫn cần review merge và không để hai người áp dụng migration/deploy đồng thời.

## 3. Nhật ký bàn giao

Writer cập nhật PROGRESS sau mốc: commit nếu có, file chính, script/thao tác đã chạy, kết quả, mocks, blocker, job/phiên đang chạy, bước tiếp.

Phiên sau đọc APPROVAL và PROGRESS, kiểm tra trạng thái thực tế, xác định ai đang viết. Không chạy lại scaffold hoặc deploy từ đầu vì chat mới.

Nếu chưa có Git, ghi rõ chưa có commit; không tạo SHA giả. Chỉ commit/push trong phạm vi người dùng đã giao và sau khi xem diff/secret.

## 4. Prompt dùng ngay — review tài liệu, chưa code

~~~text
Đọc AGENTS.md, README.md, docs/APPROVAL.md, docs/MVP.md và docs/PROGRESS.md.
Bộ Cloud PC Marketplace đang chờ chủ dự án duyệt.
Chỉ review tài liệu, chưa scaffold/cài dependency/thuê cloud/deploy hoặc cấu hình máy.
Đọc thêm ARCHITECTURE, DATA_MODEL, CONTRACT_SPEC, REMOTE_ACCESS, SECURITY và TEST_PLAN.
Tìm mâu thuẫn cụ thể về tiền, quyền, thời hạn, đặt trùng, truy cập và phạm vi.
Nêu điểm cần sửa, tác động và đề xuất; không tự coi dự án đã được duyệt.
~~~

## 5. Prompt M0 — chỉ dùng sau khi chủ dự án duyệt

~~~text
Đọc các file đầu vào và hồ sơ duyệt. Chỉ làm M0 trong phạm vi được duyệt.
Khảo sát công cụ và máy được chỉ định, không đổi OS/mở public port/tạo chi phí nếu chưa được phép.
Đối chiếu REMOTE_ACCESS và chạy spike desktop qua hai mạng khi có thiết bị.
Chứng minh grant, revoke active session, chặn reconnect, watchdog và reset.
Không xem link remote/password chia sẻ tay là tích hợp marketplace hoàn chỉnh.
Ghi phần đã kiểm tra/chưa kiểm tra, giải pháp adapter, chi phí và blocker.
Nếu chưa có máy hoặc ngân sách cần thiết, chuẩn bị phần độc lập rồi hỏi đúng thông tin thiếu.
~~~

## 6. Prompt writer theo mốc — sau duyệt

~~~text
Đọc AGENTS, README, APPROVAL, MVP, PROGRESS và tài liệu kỹ thuật liên quan.
Xác nhận mốc tiếp theo được phép theo DEVELOPMENT_GUIDE; không tự nhảy mốc.
Kiểm tra checkout/công cụ/dependency thực tế và bảo toàn thay đổi có sẵn.
Triển khai mốc đó, tạo và ghi script trước khi chạy kiểm tra.
Không giả receipt, desktop hoặc deployment; mock phải có nhãn và nêu phần còn thiếu.
Cập nhật README và PROGRESS, báo kết quả có bằng chứng và bước tiếp.
Chưa mở rộng MVP, chưa tạo chi phí hoặc mainnet.
~~~

## 7. Prompt reviewer theo mốc

~~~text
Đọc AGENTS, APPROVAL, MVP, PROGRESS và diff của mốc vừa xong.
Chỉ đọc/review, chưa sửa file, chưa áp dụng migration hoặc deploy.
Ưu tiên: quyền server/RLS; wallet proof; giá/quote; atomic booking; chain receipt;
state machine escrow và timeout; revoke active session; reconnect; cleanup và worker recovery.
Mỗi lỗi cần file/vị trí, điều kiện tái hiện và tác động.
Phân biệt lỗi đã chứng minh với giả thuyết và kiểm tra chưa thực hiện.
Không báo đạt test dựa trên lời writer; dùng bằng chứng đã có hoặc ghi chưa chạy.
~~~

## 8. Prompt sửa lỗi đã review

~~~text
Đọc findings có căn cứ và kiểm tra lại code hiện tại.
Sửa đúng các lỗi được giao, không refactor hoặc mở rộng ngoài phạm vi.
Chạy kiểm tra liên quan sau khi bảo đảm script đã có, cập nhật tài liệu nếu thay behavior.
Ghi kết quả vào PROGRESS và nêu finding nào chưa thể giải quyết.
~~~

## 9. Không dùng prompt tự động toàn quyền

Không đưa API key/seed vào prompt. Không yêu cầu agent “tự làm tất cả bất kể chi phí” hoặc “tắt mọi bảo vệ”. Quyền triển khai phải cụ thể theo APPROVAL và lời chủ dự án; file hướng dẫn không tự cấp quyền sử dụng máy của người khác.
