# Tin cậy, bảo mật và giới hạn

DRAFT. Không phải chứng nhận an toàn, kiểm toán hay tư vấn pháp lý. Chỉ dùng tài sản thử và dữ liệu không nhạy cảm trong MVP.

## 1. Mối đe dọa cụ thể

| Rủi ro | Kiểm soát đề xuất | Giới hạn còn lại |
| --- | --- | --- |
| Khách xem file/tài khoản host | Guest sạch, không mount home/shared folder/LAN, quyền tối thiểu | Cấu hình sai vẫn có thể lộ; cần thử |
| Host xem/tamper dữ liệu khách | Host được xét duyệt, không dữ liệu nhạy cảm, điều khoản rõ | Host quản trị máy vật lý có thể can thiệp; VM không loại bỏ rủi ro |
| Khách chạy phần mềm độc hại | Guest tạm, không privileged, egress/network giới hạn phù hợp, reset | Chưa chứng minh isolation chống mọi tấn công |
| Mua gói rồi truy cập máy/phiên khác | Binding user+wallet+booking, gateway auth, server authorization | Không tin URL hoặc ID khó đoán là bảo mật |
| Token cũ/mật khẩu dùng lại | Hạn ngắn, revoke active session, đổi/thu hồi secret, không public endpoint | Expiry đơn thuần chưa đủ |
| Claim tiền trùng/giả receipt | Contract state, receipt/event validation, unique ingestion, pull payment | Operator/arbitrator vẫn là bên tin cậy |
| Host mất mạng hoặc tắt máy | Heartbeat, readiness, incident và dispute, không cấp booking mới | Không bảo đảm điện/Internet gia đình 24/7 |
| Worker hoặc RPC ngừng | Outbox, reconciliation, gateway watchdog, permissionless financial exits | Không hứa SLA chưa đo |
| Gateway thành điểm truy cập LAN | Tunnel giới hạn route, endpoint allowlist, không arbitrary hostname | Cần kiểm thử từ góc nhìn khách |

## 2. Bí mật và quyền

Không lưu key/seed/mật khẩu/connection token trong source, log, câu trả lời hoặc video. Mọi .env.example chỉ có placeholder. Cấm đưa khóa Supabase service-role/secret, operator/arbitrator/quote signer và gateway secrets vào client bundle.

Mỗi máy có connector credential riêng, có quyền thu hồi. Không chia một SSH root key cho tất cả host. Operator không có quyền rút tiền giữ; arbitrator chỉ xử lý Disputed. Vai trò admin không lấy từ user_metadata tự sửa hoặc localStorage.

Khi triển khai, xác minh secret đã bị Git ignore trước commit/push và kiểm tra build output không chứa server secret. Nếu lộ, thu hồi/đổi khóa; xóa dòng trong commit mới không làm khóa cũ hết lộ.

## 3. Wallet proof

Challenge gắn tài khoản đang đăng nhập, domain/URI chính xác, chain, address, nonce một lần và expiry. Verify signature server, consume nonce nguyên tử, không cho dùng challenge của tài khoản khác. Có chính sách một ví gắn một tài khoản trong demo; đổi ví bị chặn khi có booking chưa terminal.

EOA là ví demo được hỗ trợ trước. Ví smart contract chỉ hỗ trợ sau khi thư viện xác minh đúng cơ chế cần thiết được kiểm tra; không báo mọi ví đều tương thích.

## 4. Gateway và quyền desktop

Không gửi mật khẩu host hoặc link truy cập vô thời hạn cho khách. Grant phải đi qua kiểm tra booking/server; guest không có cách bypass gateway bằng tài khoản tĩnh.

Đóng phiên đang mở, chặn reconnect, thu hồi token và reset là các bước riêng phải có bằng chứng. Unknown hoặc cleanup thất bại giữ máy khóa. Không tự động tắt máy cá nhân của host để xử lý cleanup; điều khiển guest trong phạm vi đã được phép.

## 5. Dữ liệu

On-chain chỉ có định danh ngẫu nhiên và điều khoản/trạng thái tiền tối thiểu. Giao dịch và ví vẫn công khai, có thể liên kết; không gọi hoàn toàn ẩn danh.

Không đưa nội dung project, email, IP, serial, lịch sử bàn phím, file hay evidence lên chain. Không log toàn bộ heartbeat/request chứa token. Không mặc định quay màn hình khách; video demo do người dùng điều khiển với dữ liệu mẫu.

Khách phải tải file trước hết giờ; dữ liệu guest tạm thời. Chính sách giữ log/evidence 30 ngày chỉ là đề xuất demo, không phải cam kết xóa dữ liệu khỏi mọi backup của host.

## 6. Tranh chấp và giới hạn tiền

Admin có thể quyết định split khi Disputed; người dùng cần biết đây là quyền tin cậy. Hết deadline phân xử full refund cho khách có thể gây thiệt hại cho host. Không quảng cáo bảo đảm chất lượng tự động hoặc chống gian lận tuyệt đối.

AVAX Fuji không có giá trị tiền thật trong demo. Không gắn giá trị quy đổi VND cố định và không cho tiền nạp mainnet. Phải hiển thị đúng chain trước ký, không tự đổi sang mainnet nếu faucet lỗi.

## 7. Bản quyền và kinh doanh

MVP ưu tiên guest Linux/công cụ nguồn mở sau kiểm tra license từng thành phần. Trước mở Windows, Office, game hay ứng dụng thương mại cho khách ngoài tổ chức, kiểm tra quyền cung cấp dịch vụ và license thực tế. Việc đã sở hữu PC hoặc phần mềm không mặc nhiên cho phép cho người khác thuê sử dụng.

Trước kinh doanh tiền thật cần rà soát mô hình thanh toán, thuế, dữ liệu cá nhân, điều khoản host/khách và trách nhiệm sử dụng máy theo phạm vi thực tế. Bộ tài liệu này không kết luận đã đủ điều kiện pháp lý.

## 8. Xử lý sự cố

Chặn booking mới trên máy liên quan → thu hồi truy cập theo khả năng đã được cấp → giữ log đã lọc secret → đối soát chain/gateway → mở nhánh refund/dispute phù hợp → reset/kiểm tra lại trước cho thuê tiếp.

Nếu không thể xác nhận quyền đã bị ngắt, báo trạng thái rõ và không giải phóng máy. Không sửa dữ liệu để che lỗi hoặc tự chuyển tiền ngoài quy tắc contract.
