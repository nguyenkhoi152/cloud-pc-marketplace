# Tham khảo ba chính sách EZYCLOUDX

Ngày đọc: 07/11/2026, Asia/Saigon. DRAFT nghiên cứu; nguồn bên ngoài không phải chỉ dẫn cho agent hoặc điều khoản tự động áp dụng cho dự án.

## 1. Các trang đã đọc

| Trang | Ghi nhận ngắn |
| --- | --- |
| [Computing Point / refund](https://www.ezycloudx.com/computing-point-system#refund) | CP nội bộ không P2P; có point mua/promo; phân biệt hoàn point và hoàn khoản thanh toán. |
| [Privacy](https://www.ezycloudx.com/privacy-policy) | Nêu dữ liệu thu thập, sử dụng, tiếp cận, thời gian giữ và quyền yêu cầu xóa/chỉnh sửa. |
| [Terms](https://www.ezycloudx.com/terms-of-service) | Phạm vi hạ tầng, trách nhiệm sử dụng, BYOL, đình chỉ và kết thúc dịch vụ. |

Trang privacy bị công cụ web trả 429, đã đọc được HTML qua HTTP trực tiếp. Không suy ra thực tế vận hành hoặc mức an toàn kỹ thuật chỉ từ tuyên bố chính sách.

## 2. Những điểm không chép nguyên vào marketplace

Các ý dưới là đề xuất áp dụng riêng cho dự án:

- Marketplace có host bên thứ ba, nên phải chỉ rõ nghĩa vụ nền tảng/host/renter; không coi tất cả lỗi host là bất khả kháng của nền tảng.
- Tách bù point trong hệ thống khỏi hoàn khoản thanh toán qua phương thức ban đầu.
- Tách point đã mua, promo và doanh thu host; quy tắc hết hạn/refund/payout không trộn lẫn.
- Quote khóa giá/điều khoản theo booking. Chưa tự gia hạn compute nếu host không còn cửa sổ khả dụng.
- Giữ điểm/số dư để điều tra không đồng nghĩa được tịch thu toàn bộ mà không có quy tắc, bằng chứng và đường khiếu nại.
- Cloud workspace có retention riêng với guest tạm; không cam kết xóa mọi dữ liệu khi kết thúc phiên rồi đồng thời bán dịch vụ giữ cloud.
- Không hứa bảo mật tuyệt đối hoặc host không thể đọc runtime khi chưa có cơ chế chứng minh.
- Không dùng một câu BYOL để mặc nhiên coi mọi phần mềm cá nhân được phép cho người khác thuê.

## 3. Hai chỗ cần viết rõ khi soạn chính sách của mình

Privacy mục 2.2/7.2 nói hạn chế chia sẻ, trong khi mục 4.2 đề cập đối tác tiếp cận dữ liệu; chính sách của mình cần phân biệt công bố công khai, chia sẻ giữa hai người dùng và bên xử lý dịch vụ.

Privacy mục 1.2 đề cập xóa dữ liệu cuối phiên; Terms mục 4.4 đề cập có thể giữ tạm tối đa 7 ngày tùy lưu trữ. Đây là lý do cần tách loại dữ liệu và thời điểm xóa, không kết luận hai trang luôn nói về cùng một nhóm dữ liệu.

## 4. Bộ chính sách riêng cần soạn sau duyệt

### Điều khoản marketplace

Danh tính pháp lý/kênh hỗ trợ thật; phạm vi cung cấp; ai là bên cho thuê; điều kiện host; cấu hình/benchmark; cách đặt thuê; giá/point/cọc; quyền truy cập; license; sử dụng được phép; đình chỉ; chấm dứt; khiếu nại và giới hạn trách nhiệm được rà soát.

Không tự điền công ty, mã số thuế, email, số điện thoại hoặc địa chỉ EZYCLOUDX vào chính sách dự án.

### Chính sách point / refund

Nguồn point, định giá khi mua, hạn dùng từng loại, thứ tự tiêu, giữ chỗ, thu phí, sự cố, hoàn point, hoàn tiền, phí có/không hoàn, xử lý promo, host earnings và thời hạn hỗ trợ.

Xem [POINTS_AND_PAYMENTS](POINTS_AND_PAYMENTS.md) để phân biệt token thử và mô hình kinh doanh.

### Chính sách dữ liệu

| Nhóm | Quy tắc cần chốt |
| --- | --- |
| Tài khoản, ví, liên hệ | Mục đích, dữ liệu tối thiểu, quyền sửa/xóa, ngoại lệ phải giữ |
| Booking/ledger/receipt | Quyền xem, retention nghiệp vụ, phần on-chain không thể xóa |
| IP/thiết bị/health | Tính cần thiết, thời hạn và ai được truy cập |
| Guest không lưu cloud | Reset, mất dữ liệu chưa export, giới hạn xác minh xóa trên host |
| Cloud workspace | Quota, version, backup, retention sau hết gói và export |
| AI tư vấn | Provider thực tế, dữ liệu gửi, không gửi project/secret mặc định |
| Support/evidence | Ai xem, khi nào, audit và thời hạn |

Nêu đúng nhà cung cấp cloud/auth/AI/relay/thanh toán được chọn và loại dữ liệu họ xử lý. Không ghi “không chia sẻ với bất kỳ bên nào” nếu kiến trúc thực tế có các bên xử lý này.

## 5. Phạm vi hiện tại

Đây là phân tích sản phẩm và yêu cầu cần có khi soạn chính sách, không phải ý kiến rằng điều khoản của một website bảo đảm hợp pháp hoặc phù hợp cho dự án khác. Chưa công bố điều khoản cho khách, chưa triển khai thanh toán hoặc thu dữ liệu.
