# Chính sách vận hành chợ — bản để duyệt

DRAFT 0.2, 07/11/2026. **Thiết kế chính sách, chưa phải điều khoản đã công bố hoặc cơ chế phạt đã triển khai.** Tham số phải duyệt và đặc tả thành code trước khi áp dụng.

Đọc bổ sung [point/thanh toán 0.3](POINTS_AND_PAYMENTS.md) và [tham khảo EZYCLOUDX](POLICY_REFERENCE_REVIEW.md). Phải tách hoàn point/hoàn tiền/host payout và công bố đúng dữ liệu blockchain; không chép thông tin pháp nhân hoặc điều khoản nguồn thành của dự án.

## 1. Những chính sách cần có

1. Điều kiện đăng máy và xác minh host.
2. Cam kết khả dụng, maintenance và hủy.
3. Giá, tiền trả trước, host bond và trả doanh thu.
4. Sự cố, hoàn tiền, bồi hoàn và khiếu nại.
5. Sử dụng được phép/cấm.
6. Quyền riêng tư, workspace, retention và xóa.
7. Bảo mật, truy cập hỗ trợ và báo cáo sự cố.

Mỗi booking lưu policy_version/snapshot điều khoản; thay đổi sau không tự áp dụng bất lợi cho booking đã nhận.

## 2. Điều kiện host

- Là chủ thiết bị hoặc có quyền cho thuê; không dùng máy công ty/trường/người khác khi chưa được phép.
- Khai cấu hình, ứng dụng/license, vùng mạng và lịch trung thực; benchmark có thời điểm.
- Cài agent theo quyền được đồng ý, kiểm tra điện/nhiệt/mạng và khả năng reset.
- Có guest/máy sạch riêng; không chia sẻ desktop chứa dữ liệu cá nhân.
- Không quan sát/copy màn hình, file, input hoặc dùng credential khách; không cài keylogger/miner hay sửa môi trường để đánh cắp.
- Không liên hệ ngoài nền tảng bằng dữ liệu lấy từ guest, không giữ file/tiền để ép phí.

Phần mềm theo dõi sức khỏe chỉ ghi metadata cần thiết và công bố; không mặc định ghi màn hình/keystroke.

## 3. Cam kết thời gian đề xuất

Host đăng cửa sổ ít nhất 4 giờ trong pilot. Một booking thương mại đề xuất tối thiểu 30 phút, tối đa 2 giờ; có buffer chuẩn bị/sync. Những số này chưa duyệt và cần đo.

Trong cửa sổ nhận thuê: agent phải online, máy không sleep, cấu hình không bị giảm hay dùng cho tác vụ cá nhân ảnh hưởng khách. Cách cài/tắt sleep cần host cho phép, không agent tự sửa ngoài phạm vi.

Host có thể ngừng nhận phiên mới; booking đã nhận phải được phục vụ hoặc theo nhánh hủy/sự cố. Nếu chưa có booking, tắt sớm cửa sổ làm giảm điểm khả dụng/cảnh báo, không tự thu phạt tiền.

Không thể kỹ thuật bảo đảm mất điện/mạng không bao giờ xảy ra. Chỉ gắn nhãn nguồn dự phòng, uptime hoặc SLA khi có tiêu chí, bằng chứng và cơ chế bồi hoàn thực tế.

## 4. Phát hiện sự cố và quy lỗi

Thông số thử: heartbeat mỗi 10 giây; sau 30 giây đánh dấu Suspect; gián đoạn kéo dài 90 giây chuyển Incident; quá 5 phút đưa lựa chọn kết thúc/chuyển máy nếu có. Đây là mục tiêu đo, chưa là SLA.

Không kết luận host vi phạm chỉ vì heartbeat thiếu. Dùng heartbeat, probe độc lập từ hạ tầng nền tảng, trạng thái relay/gateway và kết nối khách để phân biệt:

- Mất điện/mạng/agent/guest phía host.
- Mạng hoặc client khách.
- Lỗi control plane/relay/storage của nền tảng.
- Chưa đủ bằng chứng hoặc nhiều nguyên nhân.

Metadata có chữ ký của agent chứng minh nguồn thông báo, không chứng minh host không nói dối. Gián đoạn do nền tảng không được tự lấy cọc host bù.

Khi sự cố, đóng nhận phiên mới, lưu bằng chứng tối thiểu, hiển thị tình trạng và đường hỗ trợ. Không cho thuê trùng hoặc báo đã chuyển máy mà chưa restore được checkpoint.

## 5. Tiền trả trước và host bond

Tiền trả trước của khách giữ theo booking; chưa phải cọc bồi thường tài sản. Không cần thêm cọc renter trong MVP đề xuất.

Host bond là khoản cam kết riêng. Chưa có mức cụ thể được duyệt. Cách sizing đề xuất: theo giá tối đa mỗi phiên, số phiên đồng thời và trần bồi hoàn đã công bố; khóa phần cần thiết cho mỗi booking.

- Bond không tính là doanh thu hay phí nền tảng.
- Không nhận booking mới vượt bond khả dụng nếu bond là yêu cầu.
- Không được rút phần đang bảo đảm booking/khiếu nại còn hạn.
- Có hạn giải tỏa/kháng nghị hữu hạn, không khóa tiền vô thời hạn.
- Thiếu cọc thì dừng phiên mới, không bất ngờ cắt phiên khách đang dùng.
- Chỉ trừ theo vi phạm có bằng chứng, công thức/trần đã công bố và quyết định có audit.

Không áp dụng slash tự động theo heuristic/network timeout trong bản đầu. Nếu dùng on-chain bond, cần đặc tả riêng role, trần, thời hạn, appeal và lối thoát; hợp đồng hiện tại chưa hỗ trợ.

## 6. Ma trận xử lý đề xuất

| Tình huống | Tiền thuê | Host bond / tài khoản |
| --- | --- | --- |
| Host không chuẩn bị được trước kích hoạt | Hoàn toàn bộ tiền thuê; gas đã dùng không tự hoàn | Ghi sự cố; xét vi phạm lặp, không tự phạt mất mạng |
| Khách hủy khi booking chưa kích hoạt | Theo điều kiện cancel đã công bố; MVP cũ full refund | Không trừ bond host |
| Lỗi host được xác nhận trong phiên | Đề xuất hoàn phần chưa phục vụ; phần gián đoạn/trần bồi hoàn phải chốt | Có thể bồi hoàn trong trần từ phần bond đã khóa, sau đối soát |
| Lỗi nền tảng/relay/cloud | Theo chính sách dịch vụ, không đổ mặc định cho host | Không trừ bond host nếu host không có lỗi |
| Lỗi mạng/client khách | Hỗ trợ reconnect; refund theo điều kiện công bố | Không tự phạt host |
| Chủ máy khai sai cấu hình/đánh cắp dữ liệu | Giữ payout tranh chấp, xem xét hoàn | Gỡ listing/khóa điều tra, xử lý bond chỉ theo điều khoản và bằng chứng |
| Khách phá guest/cố truy cập LAN/khách khác | Thu hồi phiên, xử lý khiếu nại theo bằng chứng | Không tự thu “thiệt hại PC” mơ hồ; tài khoản có thể bị hạn chế |
| Không đủ bằng chứng | Mở tranh chấp, không kết tội tự động | Không slash theo phỏng đoán |

Ví dụ công thức hoàn tiền đang cân nhắc: giá booking × tỷ lệ thời gian chưa phục vụ được xác nhận. Phải định nghĩa rõ khoảng chuẩn bị, gián đoạn, thời điểm lỗi, đơn vị làm tròn và trần trước code; chưa có tính phí theo phút thật trong contract hiện tại.

## 7. Khiếu nại và appeal

Khách/host xem bằng chứng đã lọc dữ liệu riêng, gửi phản hồi trong thời hạn công bố. Admin demo phân xử là bên tin cậy; không mô tả là trọng tài độc lập tự động.

Đề xuất quyền kháng nghị 24 giờ đối với kết luận trừ host bond, giữ khoản đang tranh chấp tới khi kết thúc quy trình trong thời hạn hữu hạn. Thời hạn này chưa duyệt và không được chèn vào contract fixed-price cũ mà không sửa state machine.

Không đưa file riêng hoặc lý do có PII lên chain; audit riêng chỉ người có quyền. Không phạt chỉ từ lời tố cáo của một bên.

## 8. Sử dụng được phép và cấm

Khách chỉ dùng ứng dụng/tài nguyên trong gói, theo license và giới hạn đã công bố. Tải CPU/GPU cao trong tác vụ được cho phép không tự là vi phạm; host chịu trách nhiệm cấu hình điện/nhiệt phù hợp.

Cấm vượt isolation, tấn công/quét mạng trái phép, lấy dữ liệu người khác, cài persistence/backdoor, chia sẻ lại quyền phiên hoặc khai thác trái phép tài nguyên ngoài gói. Chính sách mining/proxy/spam/bandwidth resale phải nêu rõ trước thuê; không dùng cấm mơ hồ để thu tiền phạt sau.

Không ép khách giao seed/private key, mật khẩu chính hoặc tắt bảo vệ thiết bị cá nhân.

## 9. Cloud và quyền riêng tư

Cloud là tùy chọn có quota, giá, retention và hành vi khi hết hạn rõ ràng. Không lưu cloud vẫn có metadata vận hành tối thiểu; không gọi “không lưu gì”.

Host không có quyền portal/storage quản trị. Hỗ trợ nền tảng theo least privilege, có audit, không đọc file tùy tiện. Dữ liệu đang mở trong máy host không được bảo đảm bí mật trước host có quyền quản trị; công bố giới hạn trước thuê.

Không tự xóa cloud để phạt khoản phí đang tranh chấp. Hết gói storage: cảnh báo, chuyển read-only theo chính sách và cho export trong thời hạn được công bố trước khi xử lý retention.

## 10. Trước khi nhận tiền thật

Chốt công thức refund/bồi hoàn, mức cọc, bằng chứng, kháng nghị, giới hạn trách nhiệm, thanh toán, license, thuế và dữ liệu phù hợp mô hình. Đây là bước rà soát chính sách thực tế, không có tuyên bố bộ draft đã đủ điều kiện pháp lý.
