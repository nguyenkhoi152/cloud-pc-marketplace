# Workspace cloud dùng tiếp giữa các chủ máy

DRAFT 0.2, 07/11/2026. Chưa có storage, đồng bộ, key management hoặc kiểm tra bảo mật thật.

## 1. Điều sản phẩm nên hứa trong bản đầu

Khách chọn một project/workspace gắn tài khoản. Dữ liệu đã checkpoint thành công trên cloud được mở lại khi thuê máy khác có template/ứng dụng tương thích. Máy host chỉ là nơi xử lý tạm thời.

Không hứa app đang chạy tiếp đúng RAM, toàn bộ Windows di chuyển được, mọi phần mềm đã cài và license theo máy đều chuyển được.

## 2. Ba mức persistence

| Mức | Giữ lại | Phạm vi đề xuất |
| --- | --- | --- |
| Ephemeral | Không có cloud workspace; khách tự export | Bắt buộc có lựa chọn và cảnh báo |
| Project workspace | File dự án và cấu hình được chọn, có version | Mức nên chứng minh trong MVP mở rộng |
| Full machine image / hibernate | Disk OS và có thể trạng thái VM/RAM | Mốc riêng, chưa hứa hỗ trợ |

Full image cần chuẩn VM/OS/CPU/GPU/driver, license, dữ liệu lớn và cơ chế consistency. Không gắn object storage thành ổ C: rồi khẳng định giải quyết được mọi vấn đề. Migration một thư mục giữa template tương thích đơn giản hơn.

## 3. Vòng đời

1. Khách trên thiết bị riêng chọn cloud/no-cloud và workspace; backend kiểm tra owner/quota/grant.
2. Chuẩn bị guest sạch từ template đã duyệt; lấy manifest phiên bản cloud đã xác nhận.
3. Cấp quyền chỉ đọc đúng dữ liệu cần cho booking; restore/cache vào workspace cục bộ.
4. Chạy ứng dụng; sync chỉ file đã ghi ra disk theo cơ chế checkpoint, không tự cứu nội dung ứng dụng chưa lưu.
5. Upload vào vùng staging của phiên; kiểm tra checksum, quota, path, manifest và version trước commit.
6. Hiển thị “Đã lưu lúc ... / đang đồng bộ / lỗi / có file chưa lưu”. Không báo xanh chỉ vì upload request đã gửi.
7. Khi kết thúc, ngừng input, yêu cầu ứng dụng lưu theo khả năng, tạo checkpoint cuối trong giới hạn; xác nhận kết quả rồi revoke grants/reset.
8. Phiên sau restore phiên bản cloud đã xác nhận trên host khác; khách chọn rollback khi cần.

MVP chỉ nên dùng một project nhỏ và app có cách save rõ ràng. Không triển khai backup cả disk 100 GB để chứng minh một file di chuyển.

## 4. Kiến trúc lưu trữ

Private object storage tương thích S3 là ứng viên cho blobs/checkpoints; database giữ workspace ownership, manifest và phiên bản. Object storage không mặc định là filesystem POSIX hoặc ổ đĩa có thể boot.

Mỗi workspace có định danh ngẫu nhiên, namespace tách tenant, ACL server-side, quota, version và retention. Mã hóa trên đường truyền và khi lưu; giải pháp key management phải được chọn và kiểm chứng trước quảng cáo bảo mật.

Không đặt dữ liệu bền vững chỉ trên SSD host. Nếu host tắt, bản cloud đã xác nhận vẫn độc lập. Dữ liệu thay đổi từ checkpoint cuối chưa sync có thể mất; không hứa zero data loss.

## 5. Cấp quyền tối thiểu

Guest/connector không nhận root storage key, mật khẩu cloud drive cá nhân, Supabase service key hay credential toàn tài khoản.

Read grant giới hạn workspace/version cần dùng, write grant chỉ append vùng staging của booking; không có quyền list người khác, xóa version, đổi policy hoặc ghi đè bản đã xác nhận. Đường dẫn kiểm tra canonicalization/path traversal/symlink; không tin tên file client/host.

Presigned URL là bearer token, có thể dùng lại tới hết hạn; không tự là link một lần. Nếu cần thu hồi tức thì và ràng buộc người dùng/phiên, dùng broker kiểm tra quyền mỗi yêu cầu hoặc credential/policy hỗ trợ revoke đã thử. Transfer bắt đầu trước expiry có thể còn chạy; expiry đơn thuần không bảo đảm dừng.

Nguồn: [AWS presigned URLs](https://docs.aws.amazon.com/AmazonS3/latest/userguide/using-presigned-url.html).

Khi guest bị quản trị viên host quan sát, token ngắn hạn vẫn có thể bị lấy trong lúc hợp lệ. Scope nhỏ giảm hậu quả, không biến host thành bên không thể đọc dữ liệu.

## 6. Version, rollback và chống phá dữ liệu

Giữ version/checkpoint trước; guest không được xóa hoặc sửa bản cũ. Upload từ host là dữ liệu không tin cậy: checksum chỉ xác nhận byte đã chuyển đúng, không chứng minh file chưa bị host sửa độc hại.

Server commit manifest nguyên tử, chống hai phiên cùng ghi bằng workspace lease/version check. MVP chỉ một phiên writer cho mỗi workspace; phiên thứ hai bị chặn hoặc read-only. Không để last-write-wins âm thầm phá project.

Cho khách xem/chọn checkpoint trên portal thiết bị riêng; lịch sử version giúp phục hồi nếu file lỗi. Autosave không được xóa bản tốt hoặc xóa backup. Có thể scan malware theo giới hạn đã công bố, không bảo đảm phát hiện mọi nội dung xấu.

Versioning tiêu tốn storage cho các version; cần bật rõ, quyền xóa giới hạn và lifecycle retention. Không gọi versioning là backup bất biến chống mọi admin có quyền.

Nguồn: [AWS S3 Versioning](https://docs.aws.amazon.com/AmazonS3/latest/userguide/Versioning.html).

## 7. Khi host mất điện hoặc hết phiên

Autosave đề xuất mỗi 60 giây chỉ cho file đã ghi và định dạng có consistency phù hợp; chu kỳ thực tế cần đo. Trước hết phiên cảnh báo 5 phút/1 phút để khách save. Những con số này chưa phải RPO/SLA.

Nếu host đột ngột mất điện, restore checkpoint cuối đã xác nhận ở host khác; project không nằm trên cloud chưa được bảo đảm. Không tuyên bố chuyển máy tức thời hoặc giữ nguyên RAM.

Nếu sync cuối lỗi, UI phải nêu phiên bản cuối đã lưu và phần chưa xác nhận. Không tự xóa guest khi còn workflow recovery đang được phép; cũng không giữ plaintext vô thời hạn. Cần chốt thời hạn quarantine mã hóa, quyền giữ key và thủ tục xóa trước code, hoặc giới hạn MVP chỉ kết thúc chủ động khi checkpoint đã xác nhận.

Hết thời hạn truy cập vẫn phải ngừng khách dùng; việc recovery/sync nền là quyền hẹp riêng, không kéo dài quyền desktop vô hạn. Máy chưa cleanup/reset xong không nhận khách tiếp.

## 8. Tính tương thích và thời gian khôi phục

Máy nhận workspace phải có OS/template/application version phù hợp, đủ RAM/disk/GPU theo manifest. Hiển thị estimated restore khi có số đo; không hứa file mở được trên bất kỳ PC.

Project-only không chuyển app/license; ưu tiên template cài sẵn có version. Save game, plugin, môi trường Python/CUDA và file binary có thể cần quy tắc riêng.

Ví dụ dữ liệu 10 GB trên đường truyền thực đạt 100 Mbps mất tối thiểu lý thuyết khoảng 800 giây (~13 phút 20 giây), chưa overhead. Vì vậy cần checkpoint nhỏ/delta/lazy fetch theo ứng dụng và cơ chế cache an toàn; không hứa tải cả disk trong vài giây.

## 9. Bảo mật: điều có thể và không thể hứa

- Guest riêng + không mount disk/LAN host giúp giảm nguy cơ khách lấy dữ liệu chủ máy; vẫn cần kiểm tra hypervisor/network quyền tối thiểu.
- TLS bảo vệ trên đường truyền, disk encryption bảo vệ khi lưu theo mô hình key; không ngăn host có quyền quản trị quan sát runtime.
- Mã hóa client-side chỉ giữ bí mật khi blob chưa giải mã trên host; khi guest mở project, dữ liệu/key dùng xử lý có thể bị host quan sát.
- Nền tảng giữ key server-side có thể truy cập plaintext theo quyền kỹ thuật; audit và least privilege là kiểm soát vận hành, không phải zero knowledge.
- Reset/delete key không chứng minh host độc hại chưa copy file, key, memory hoặc screenshot.

Nếu muốn bảo vệ runtime khỏi host không tin cậy, phải nghiên cứu confidential VM/computing, remote attestation, key release và toàn bộ đường GPU/display/input trên phần cứng được hỗ trợ. Đây không phải tính năng mặc định của PC dân dụng hoặc chỉ cần thêm một thư viện.

Nguồn: [Libvirt disk encryption](https://libvirt.org/formatstorageencryption.html), [NVIDIA Confidential Computing](https://docs.nvidia.com/confidential-computing/).

Không yêu cầu renter đăng nhập tài khoản chính/seed/key vào guest. Portal, ví, thanh toán và quản lý storage chạy trên thiết bị riêng; không tự lưu browser profile/mật khẩu trong workspace.

## 10. IP và danh tính

Không trả số điện thoại/email/serial/IP riêng trong listing hoặc connection metadata không cần thiết. Host chỉ nhận booking pseudonymous và route cần phục vụ.

P2P có thể cho peer biết địa chỉ IP dùng kết nối. Nếu cần che IP hai phía, dùng relay có thiết kế tương thích và đo lại độ trễ/chi phí; relay không ngăn host thấy file xử lý cục bộ.

## 11. Kiểm thử cần thêm trước nghiệm thu

- Renter A không thấy workspace B qua API, object key đoán, presigned token, manifest hoặc guest còn cache.
- Host/guest chỉ được quyền cần cho booking; revoke chặn grant mới và request qua broker, kiểm tra transfer đang mở riêng.
- Hết quota/upload fail không báo đã save; checksum/manifest mismatch bị chặn.
- Hai phiên writer bị chặn/được giải quyết rõ; không có lost update.
- Host A save project → checkpoint xác nhận → revoke/reset → host B restore → nội dung đúng.
- Rollback bản cũ khi guest upload file sai; guest không xóa version.
- Power loss không giả restore phần chưa sync; hiển thị last saved chính xác.
- No-cloud không âm thầm upload; dữ liệu export xong không lưu lại trong cloud workspace.
- Reset làm renter sau không thấy file, credential, mount hoặc process trước.
- Không chụp/log file/secret thật để làm bằng chứng.

## 12. Giá và retention

Storage có giá/quota riêng, có thể theo GB/tháng; bandwidth/checkpoint/version cũng có chi phí. Chưa chốt nhà cung cấp hoặc giá thương mại.

Đề xuất thông báo trước khi hết hạn, chuyển read-only và cho export theo khoảng đã công bố. Chưa chốt thời hạn xóa cloud/backup; không tự áp con số 30 ngày của log demo vào project khách. Chính sách no-cloud không loại bỏ log thanh toán/vận hành tối thiểu cần thiết.
