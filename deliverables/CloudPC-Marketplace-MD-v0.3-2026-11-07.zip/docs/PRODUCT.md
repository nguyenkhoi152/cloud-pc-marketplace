# Ý tưởng và mô hình kinh doanh

Trạng thái: DRAFT chờ duyệt. Quyết định tại [APPROVAL](APPROVAL.md).

Yêu cầu sản phẩm mới nhất nằm tại [thiết kế 0.2](PLATFORM_DESIGN_V02.md): bổ sung cam kết host, chính sách/cọc, AI tư vấn có thể chọn và cloud workspace. Các phần định giá/phạm vi dưới đây là đề xuất đầu, chưa là quyết định triển khai.

## 1. Vấn đề và khách hàng

Giả thuyết: có người cần cấu hình mạnh trong thời gian ngắn nhưng chưa muốn mua máy; đồng thời có chủ máy đủ năng lực cung cấp môi trường thuê vào giờ trống. Cả nhu cầu trả tiền, nguồn cung ổn định và biên lợi nhuận đều chưa được kiểm chứng.

Người đầu tiên nên tiếp cận: sinh viên cần môi trường lập trình đã cài sẵn; nhóm học/đào tạo có buổi thực hành. Đây là lựa chọn đề xuất để thử nhanh, không phải kết luận thị trường đã đủ lớn.

Nguồn máy ban đầu: máy chuyên dụng của người quen/đối tác đã duyệt. Không cho khách vào desktop cá nhân đang có email, tài khoản ngân hàng hoặc file riêng.

## 2. Giá trị hai phía

- Khách: tìm được máy theo nhu cầu, thấy trước giá và giới hạn phiên, không phải tự cấu hình cloud.
- Chủ máy: đăng cấu hình và khoảng thời gian sẵn sàng, nhận tiền theo phiên hoàn tất, xem thu nhập thực tế.
- Nền tảng: xét duyệt nguồn máy, ghép khách, kiểm soát quyền truy cập, giữ tiền, đối soát và hỗ trợ.

Không hứa thu nhập thụ động cố định cho host; việc có khách phụ thuộc nhu cầu và khả dụng.

## 3. Tầm nhìn ba nhóm dịch vụ

| Nhóm | Mục tiêu | Bản thi |
| --- | --- | --- |
| Work/Dev | Desktop học tập/lập trình | Làm một môi trường Linux thật |
| Gaming | Truyền hình ảnh mượt, tương thích game | Chưa triển khai, không quảng cáo chơi được mọi game |
| GPU Studio | 3D, video, tác vụ AI | Chưa triển khai, cần kiểm tra GPU và bản quyền |

Dùng cùng nền tảng tài khoản, listing, booking và thanh toán. Không mặc định mọi loại GPU/PC phù hợp cả ba.

## 4. Mô hình thu phí

Đề xuất thương mại: phí trên phần tiền host nhận từ phiên; sau này có thể có gói nhóm và lưu trữ. Bản demo dùng 10% phần trả host, 0.01 AVAX Fuji/gói 15 phút chỉ để minh họa.

Nếu một phiên giả định có doanh thu 100.000đ và phần host được hưởng trước phí là toàn bộ giá, phí 10% là 10.000đ; host nhận 90.000đ. Chưa trừ chi phí của mỗi bên. Ví dụ không xác nhận giá thị trường.

Khi hoàn tiền toàn bộ, không thu phí nền tảng trên tiền phiên. Hoàn một phần chỉ thu phí trên phần thực trả host. Gas đã dùng không do hợp đồng hoàn.

## 5. Chi phí và lợi nhuận cần đo

- Host: điện, Internet, khấu hao, thời gian hỗ trợ và cài môi trường, bản quyền.
- Nền tảng: gateway/relay và băng thông, database/auth, worker, lưu log, hỗ trợ, hoàn tiền và thanh toán.
- Khách: giá phiên, mạng truy cập và gas trong mô hình test.

Lợi nhuận nền tảng = phí thực thu − chi phí vận hành phân bổ. Ít vốn mua máy không có nghĩa không có chi phí; không cam kết rẻ hơn các dịch vụ có sẵn.

## 6. Cạnh tranh và giả thuyết khác biệt

AirGPU cung cấp Cloud PC nhiều mục đích; Vast.ai có quy trình onboarding host GPU; Salad chạy tác vụ tính toán trên tài nguyên người dùng. Không gọi Salad là dịch vụ desktop tương đương.

Khác biệt đề xuất kiểm chứng: hỗ trợ tiếng Việt, môi trường học có sẵn, máy khu vực gần khách và đặt thuê ngắn dễ hiểu. Chưa có dữ liệu chứng minh ưu thế độ trễ hoặc giá.

Nguồn và giá tham khảo tại [SOURCES](SOURCES.md); không dùng tên/giá đối thủ làm dự báo doanh thu.

## 7. Kiểm chứng trước mở rộng

Phỏng vấn khoảng 10 khách tiềm năng và 3 host: ứng dụng cần chạy, cấu hình hiện tại, thời gian cần thuê, dữ liệu nhạy cảm, giới hạn chờ, mức sẵn sàng trả và thời điểm máy trống.

Đo từ thử nghiệm: tỷ lệ kết nối thành công, thời gian chuẩn bị, phút gián đoạn, reconnect, chi phí relay/phiên, chi phí hỗ trợ, tỷ lệ khách quay lại và lý do từ chối. Không điền số liệu hoặc lời chứng thực giả vào slide.

## 8. Vì sao dùng Avalanche

Giữ khoản trả trước và thực hiện quy tắc chia tiền/hoàn tiền có thể kiểm tra; khách giữ ví và rút khoản được ghi có. Chất lượng dịch vụ, danh tính host và dữ liệu vận hành vẫn do nền tảng chịu trách nhiệm.

Đây là hệ thống có trung gian vận hành và phân xử. Không pitch là loại bỏ hoàn toàn niềm tin hoặc làm tiền tệ mới.
